﻿#include "shopinformation.h"
#include "ui_shopinformation.h"
#include <QSqlDatabase>
#include <QDebug>
#include <QMessageBox>
#include <QSqlError>
#include <QSqlQuery>//对sql语句进行操作
#include <QVariantList>
#include <QSqlTableModel>
#include <QSqlRecord>
#include <QMenuBar>
#include <QMenu>

ShopInformation::ShopInformation(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::ShopInformation)
{
    ui->setupUi(this);
    //添加数据库
    QSqlDatabase db=QSqlDatabase::addDatabase("QSQLITE");

    //连接数据库
    /*
      数据库中的表：
      商铺信息表 shop
      业主信息表 shopOwner
      公司员工表 companyStaff
    */
    db.setDatabaseName("info.db");


    //打开数据库
    if(!db.open())
    {
        QMessageBox::warning(this,QStringLiteral("打开错误"),db.lastError().text());
        return;
    }


}

ShopInformation::~ShopInformation()
{
    delete ui;
}

//登录的业主的账号
void  ShopInformation::receiveshopOwner(QString identity)
{
    this->ownerid=identity;
}
void  ShopInformation::receiveData(QString identity)
{
    ui->label_shopID->setText(identity);
    this->shopId=identity;
    //初始化店铺状态
    QSqlQuery query;
    QString sq0=QString("select * from shop where id='%1'").arg(identity);
    query.exec(sq0);
    query.next();
    ui->label_shopID->setText(query.value(0).toString());
    ui->label_shopArea->setText(query.value(9).toString()+QStringLiteral("平方米"));
    ui->label_shopRent->setText(query.value(3).toString()+QStringLiteral("万元"));
    ui->label_shopClass->setText(query.value(10).toString());
    ui->label_shopState->setText(query.value(8).toString());


}

void  ShopInformation::receiveDataFromPersonalCenter(QString identity)
{
    //初始化店铺状态
    QSqlQuery query;
    QString sq0=QString("select * from shopOwner where id='%1'").arg(identity);
    query.exec(sq0);
    query.next();

    sq0=QString("select * from shop where id='%1'").arg(query.value(3).toString());
    query.exec(sq0);
    query.next();

    ui->label_shopID->setText(query.value(0).toString());
    ui->label_shopArea->setText(query.value(9).toString()+QStringLiteral("平方米"));
    ui->label_shopRent->setText(query.value(3).toString()+QStringLiteral("万元"));
    ui->label_shopClass->setText(query.value(10).toString());
    ui->label_shopState->setText(query.value(8).toString());

    ui->pushButton->setEnabled(false);
}
//朕再看看
void ShopInformation::on_pushButton_2_clicked()
{
    ui->pushButton->setEnabled(true);
    this->close();
}

//确认选择
void ShopInformation::on_pushButton_clicked()
{
    //QMessageBox::warning(this,"warning",this->ownerid,QMessageBox::Yes,QMessageBox::No);
    QSqlQuery query1;
    QString sq1=QString("select * from shopOwner where id='%1'").arg(this->ownerid);
    query1.exec(sq1);
    query1.next();
    QString ownername=query1.value(1).toString();
    if(query1.value(3).toInt()!=0)
    {
        ui->pushButton->setEnabled(false);
        QMessageBox::warning(this,"warning",QStringLiteral("您已经有商铺了~"),QMessageBox::Yes,QMessageBox::No);
    }
    else {
        QSqlQuery query;
        QString sq0=QString("update shopOwner set shopId='%1' where id='%2'").arg(this->shopId).arg(this->ownerid);
        query.exec(sq0);
        sq0=QString("update shopOwner set shopState='%1' where id='%2'").arg(QStringLiteral("申请中")).arg(this->ownerid);
        query.exec(sq0);
        QString sq11=QString("update shop set ownername='%1' where id='%2'").arg(ownername).arg(this->shopId);
        query.exec(sq11);

        emit sendData(this->shopId);
        this->close();
    }
}
