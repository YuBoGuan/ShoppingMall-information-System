﻿#include "shopowner.h"
#include "ui_shopowner.h"
#include <QMessageBox>
shopOwner::shopOwner(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::shopOwner)
{
    ui->setupUi(this);
}

shopOwner::~shopOwner()
{
    delete ui;
}

void  shopOwner::receiveData(QString identity)
{
   this->setWindowTitle(identity);
}

void shopOwner::receiveDataFromLogin(QString identity)
{
    this->ownerid=identity;
    //QMessageBox::warning(this,"warning",this->ownerid,QMessageBox::Yes,QMessageBox::No);
}
//进场看看
void shopOwner::on_pushButton_APplyForAdmission_clicked()
{
    APplyForAdmissionPro =new ShopDistribution;
    connect(this,SIGNAL(sendDataToShopDistribution(QString)),APplyForAdmissionPro,SLOT(receiveDataFromshopOwner(QString)));
    emit sendDataToShopDistribution(this->ownerid);
    APplyForAdmissionPro->show();
}

// 申请转租
void shopOwner::on_pushButton_Sublease_clicked()
{
    SubleasePro =new Sublease;
    SubleasePro->show();
}

//缴费信息
void shopOwner::on_pushButton_Payment_clicked()
{
    PaymentPro =new Payment;
    PaymentPro->show();
}

//个人中心
void shopOwner::on_pushButton_PersonalCenter_clicked()
{
    PersonalCenterPro =new PersonalCenter;
    connect(this,SIGNAL(sendDataToPersonalCenter(QString)),PersonalCenterPro,SLOT(receiveDataFromshopOwner(QString)));
    emit sendDataToPersonalCenter(this->ownerid);
    PersonalCenterPro->show();
}
