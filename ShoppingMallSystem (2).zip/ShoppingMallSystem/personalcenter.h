﻿#ifndef PERSONALCENTER_H
#define PERSONALCENTER_H

#include <QMainWindow>
#include"personalinformation.h"
#include"shopinformation.h"
namespace Ui {
class PersonalCenter;
}

class PersonalCenter : public QMainWindow
{
    Q_OBJECT

public:
    explicit PersonalCenter(QWidget *parent = nullptr);
    ~PersonalCenter();

signals:
    void sendDataToShopinformation(QString data);

    void sendDataToPersonalInformation(QString data);

private slots:
    void  receiveDataFromshopOwner(QString identity);

    void  receiveDataFromPersonalInformation(QString identity);

    void on_pushButton_clicked();

    void on_pushButton_3_clicked();

    void on_pushButton_2_clicked();

private:
    Ui::PersonalCenter *ui;
    PersonalInformation *PersonalInformationPro;
    ShopInformation *ShopInformationPro;
    QString ownerid;
};

#endif // PERSONALCENTER_H
