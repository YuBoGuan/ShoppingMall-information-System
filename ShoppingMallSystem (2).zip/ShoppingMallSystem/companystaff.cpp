﻿#include "companystaff.h"
#include "ui_companystaff.h"
#include <QSqlDatabase>
#include <QDebug>
#include <QMessageBox>
#include <QSqlError>
#include <QSqlQuery>//对sql语句进行操作
#include <QVariantList>
#include <QSqlTableModel>
#include <QSqlRecord>

companyStaff::companyStaff(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::companyStaff)
{
    ui->setupUi(this);
}

companyStaff::~companyStaff()
{
    delete ui;
}


void  companyStaff::receiveData(QString identity)
{
    this->setWindowTitle(identity);
}



void companyStaff::on_pushButton_DatabaseManagement_clicked()
{
    DataBasePro =new DataBase;
    DataBasePro->show();
}


void companyStaff::on_pushButton_ShowShop_clicked()
{
    ShopDistributionPro =new ShopDistribution;
    connect(this,SIGNAL(sendDataToShopDistribution(QString)),ShopDistributionPro,SLOT(receiveDataFromcompanyStaff(QString)));
    emit sendDataToShopDistribution("");
    ShopDistributionPro->show();
}
