﻿#ifndef SUCCESSFULPAYMENT_H
#define SUCCESSFULPAYMENT_H

#include <QMainWindow>

namespace Ui {
class SuccessfulPayment;
}

class SuccessfulPayment : public QMainWindow
{
    Q_OBJECT

public:
    explicit SuccessfulPayment(QWidget *parent = nullptr);
    ~SuccessfulPayment();

private slots:
    void on_pushButton_clicked();

private:
    Ui::SuccessfulPayment *ui;
};

#endif // SUCCESSFULPAYMENT_H
