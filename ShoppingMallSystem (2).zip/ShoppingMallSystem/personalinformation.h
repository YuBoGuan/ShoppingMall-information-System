﻿#ifndef PERSONALINFORMATION_H
#define PERSONALINFORMATION_H

#include <QMainWindow>

namespace Ui {
class PersonalInformation;
}

class PersonalInformation : public QMainWindow
{
    Q_OBJECT

public:
    explicit PersonalInformation(QWidget *parent = nullptr);
    ~PersonalInformation();

signals:
    void sendDataToPersonalCenter(QString data);

private slots:

    void  receiveDataFromPersonalCenter(QString identity);

    void on_pushButton_2_clicked();

    void on_pushButton_3_clicked();

    void on_pushButton_clicked();

private:
    Ui::PersonalInformation *ui;
    QString ownerid;
};

#endif // PERSONALINFORMATION_H
