﻿#include "personalcenter.h"
#include "ui_personalcenter.h"
#include <QSqlDatabase>
#include <QDebug>
#include <QMessageBox>
#include <QSqlError>
#include <QSqlQuery>//对sql语句进行操作
#include <QVariantList>
#include <QSqlTableModel>
#include <QSqlRecord>

PersonalCenter::PersonalCenter(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::PersonalCenter)
{
    ui->setupUi(this);
}

PersonalCenter::~PersonalCenter()
{
    delete ui;
}

//设置个人信息
void PersonalCenter::on_pushButton_clicked()
{
    PersonalInformationPro =new PersonalInformation;
    connect(this,SIGNAL(sendDataToPersonalInformation(QString)),PersonalInformationPro,SLOT(receiveDataFromPersonalCenter(QString)));
    connect(PersonalInformationPro,SIGNAL(sendDataToPersonalCenter(QString)),this,SLOT(receiveDataFromPersonalInformation(QString)));
    emit sendDataToPersonalInformation(this->ownerid);
    PersonalInformationPro->show();
}

//修改信息后更新显示在个人中心的个人信息
void  PersonalCenter::receiveDataFromPersonalInformation(QString identity)
{
    QSqlQuery query;
    QString sq0=QString("select * from shopOwner where id='%1'").arg(this->ownerid);
    query.exec(sq0);
    query.next();
    ui->label_name->setText(query.value(1).toString());
    ui->label_id->setText(query.value(0).toString());
    ui->label_tel->setText(query.value(4).toString());
    ui->label_shopId->setText(query.value(3).toString());
    ui->label_propertyId->setText(query.value(5).toString());
}
void PersonalCenter::receiveDataFromshopOwner(QString identity)
{
    this->ownerid=identity;
    QSqlQuery query;
    QString sq0=QString("select * from shopOwner where id='%1'").arg(identity);
    query.exec(sq0);
    query.next();
    ui->label_name->setText(query.value(1).toString());
    ui->label_id->setText(query.value(0).toString());
    ui->label_tel->setText(query.value(4).toString());
    ui->label_shopId->setText(query.value(3).toString());
    ui->label_propertyId->setText(query.value(5).toString());
}

void PersonalCenter::on_pushButton_3_clicked()
{
    this->close();
}

//查看我的商铺
void PersonalCenter::on_pushButton_2_clicked()
{
    ShopInformationPro =new ShopInformation;
    connect(this,SIGNAL(sendDataToShopinformation(QString)),ShopInformationPro,SLOT(receiveDataFromPersonalCenter(QString)));
    emit sendDataToShopinformation(this->ownerid);
    ShopInformationPro->show();
}
