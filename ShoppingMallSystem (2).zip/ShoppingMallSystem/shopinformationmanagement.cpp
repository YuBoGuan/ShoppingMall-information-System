﻿#include "shopinformationmanagement.h"
#include "ui_shopinformationmanagement.h"
#include"QMessageBox"
#include <QSqlDatabase>
#include <QDebug>
#include <QMessageBox>
#include <QSqlError>
#include <QSqlQuery>//对sql语句进行操作
#include <QVariantList>
#include <QSqlTableModel>
#include <QSqlRecord>

ShopInformationManagement::ShopInformationManagement(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::ShopInformationManagement)
{
    ui->setupUi(this);
}

ShopInformationManagement::~ShopInformationManagement()
{
    delete ui;
}

//返回商场
void ShopInformationManagement::on_pushButton_2_clicked()
{
    this->close();
}

void ShopInformationManagement::receiveDataFromShopDistribution(QString identity)
{
    this->shopID=identity;
    //初始化店铺状态
    QSqlQuery query;
    QString sq0=QString("select * from shop where id='%1'").arg(this->shopID);
    query.exec(sq0);
    query.next();
    ui->label_shopID->setText(query.value(0).toString());
    ui->label_shopArea->setText(query.value(9).toString()+QStringLiteral("平方米"));
    ui->label_shopRent->setText(query.value(3).toString()+QStringLiteral("万元"));
    ui->label_shopClass->setText(query.value(10).toString());
    ui->label_shopState->setText(query.value(8).toString());

    sq0=QString("select * from shopOwner where shopId='%1'").arg(this->shopID);
    query.exec(sq0);
    query.next();
    ui->label_ownerName->setText(query.value(1).toString());
    ui->label_ownerId->setText(query.value(0).toString());
    ui->label_ownerTel->setText(query.value(4).toString());

}

//通过验证
void ShopInformationManagement::on_pushButton_clicked()
{

}
