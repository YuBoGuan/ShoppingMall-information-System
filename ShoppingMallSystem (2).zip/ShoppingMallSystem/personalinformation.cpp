﻿#include "personalinformation.h"
#include "ui_personalinformation.h"
#include <QSqlDatabase>
#include <QDebug>
#include <QMessageBox>
#include <QSqlError>
#include <QSqlQuery>//对sql语句进行操作
#include <QVariantList>
#include <QSqlTableModel>
#include <QSqlRecord>

PersonalInformation::PersonalInformation(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::PersonalInformation)
{
    ui->setupUi(this);
    //设置密码输入格式
    ui->lineEdit_tel->setPlaceholderText(QStringLiteral("请输入电话号码"));
    ui->lineEdit_name->setPlaceholderText(QStringLiteral("请输入昵称"));
    ui->lineEdit_mailbox->setPlaceholderText(QStringLiteral("请输入邮箱"));

    ui->lineEdit_password->setEchoMode(QLineEdit::PasswordEchoOnEdit );
    ui->lineEdit_password->setPlaceholderText(QStringLiteral("请输入密码"));

    ui->lineEdit_password_again->setEchoMode(QLineEdit::PasswordEchoOnEdit );
    ui->lineEdit_password_again->setPlaceholderText(QStringLiteral("请再次输入密码"));
}

PersonalInformation::~PersonalInformation()
{
    delete ui;
}

//返回个人中心
void PersonalInformation::on_pushButton_2_clicked()
{
    this->close();
}

void  PersonalInformation::receiveDataFromPersonalCenter(QString identity)
{
    this->ownerid=identity;
}

//确认修改
void PersonalInformation::on_pushButton_3_clicked()
{
    QString password=ui->lineEdit_password->text();
    QString password_again=ui->lineEdit_password_again->text();
    if(password==password_again)
    {
        QSqlQuery query;
        QString sq0=QString("update shopOwner set ownername='%1' where id='%2'").arg(ui->lineEdit_name->text()).arg(this->ownerid);
        query.exec(sq0);
        sq0=QString("update shopOwner set phonenumber='%1' where id='%2'").arg(ui->lineEdit_tel->text()).arg(this->ownerid);
        query.exec(sq0);
        QString sq11=QString("update shopOwner set mailBox='%1' where id='%2'").arg(ui->lineEdit_mailbox->text()).arg(this->ownerid);
        query.exec(sq11);
        sq11=QString("update shopOwner set passId='%1' where id='%2'").arg(ui->lineEdit_password->text()).arg(this->ownerid);
        query.exec(sq11);
        QMessageBox::warning(this,"warning",QStringLiteral("修改信息成功"),QMessageBox::Yes,QMessageBox::No);
        emit sendDataToPersonalCenter("");
        this->close();
    }
    else {
        QMessageBox::warning(this,"warning",QStringLiteral("两次密码输入不一致，请重新输入"),QMessageBox::Yes,QMessageBox::No);
    }
}

//选择头像
void PersonalInformation::on_pushButton_clicked()
{

}
