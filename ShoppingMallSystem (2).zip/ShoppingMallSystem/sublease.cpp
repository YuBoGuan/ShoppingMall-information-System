﻿#include "sublease.h"
#include "ui_sublease.h"

Sublease::Sublease(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::Sublease)
{
    ui->setupUi(this);
}

Sublease::~Sublease()
{
    delete ui;
}


