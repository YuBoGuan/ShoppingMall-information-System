﻿#ifndef DATABASE_H
#define DATABASE_H

#include <QMainWindow>
#include <QSqlTableModel>
namespace Ui {
class DataBase;
}

class DataBase : public QMainWindow
{
    Q_OBJECT

public:
    explicit DataBase(QWidget *parent = nullptr);
    ~DataBase();
    void setModel();


private slots:
    void on_buttonAdd_clicked();

    void on_buttonDel_clicked();

    void on_buttonSure_clicked();

    void on_buttonCancel_clicked();

    void on_buttonShow_clicked();

    void on_buttonFind_clicked();

    void on_action_shop_triggered();

    void on_action_shopowner_triggered();

    void on_action_comoanystuff_triggered();

private:
    Ui::DataBase *ui;

    //设置模型
    QSqlTableModel *model;
    QString databaseType;//商铺 业主 公司职员
};

#endif // DATABASE_H
