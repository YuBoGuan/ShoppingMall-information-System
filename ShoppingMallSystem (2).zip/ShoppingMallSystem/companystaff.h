﻿#ifndef COMPANYSTAFF_H
#define COMPANYSTAFF_H

#include <QMainWindow>
#include"database.h"
#include"shopdistribution.h"

namespace Ui {
class companyStaff;
}

class companyStaff : public QMainWindow
{
    Q_OBJECT

public:
    explicit companyStaff(QWidget *parent = nullptr);
    ~companyStaff();

signals:
    void sendDataToShopDistribution(QString data);

private slots:
    void  receiveData(QString identity);


    void on_pushButton_DatabaseManagement_clicked();

    void on_pushButton_ShowShop_clicked();

private:
    Ui::companyStaff *ui;
    DataBase *DataBasePro;
    ShopDistribution *ShopDistributionPro;
};

#endif // COMPANYSTAFF_H
