﻿#include "shopdatabase.h"
#include "ui_shopdatabase.h"
#include <QSqlDatabase>
#include <QDebug>
#include <QMessageBox>
#include <QSqlError>
#include <QSqlQuery>//对sql语句进行操作
#include <QVariantList>
#include <QSqlTableModel>
#include <QSqlRecord>
#include <QMenuBar>
#include <QMenu>

ShopDatabase::ShopDatabase(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::ShopDatabase)
{
    ui->setupUi(this);

    //菜单栏

    //添加菜单

    //工具栏
    //状态栏
    //核心控件
    //



    //打印qt支持的数据库驱动
    qDebug()<<QSqlDatabase::drivers();

    //添加数据库
    QSqlDatabase db=QSqlDatabase::addDatabase("QSQLITE");

    //连接数据库
    db.setDatabaseName("info.db");
    /*
      数据库中的表：
      商铺信息表 shop
      业主信息表 shopOwner
      公司员工表 companyStaff
    */

    //打开数据库
    if(!db.open())
    {
        QMessageBox::warning(this,QStringLiteral("打开错误"),db.lastError().text());
        return;
    }


    //创建表
    QSqlQuery query;
    /*
    query.exec("create table shop("
               "id int primary key,"
               "name varchar(255), "
               "ownername varchar(255), "
               "RentPrice int,"
               "waterfee int,"
               "electricityfee int,"
               "propertyfee int,"
               "contractId int)");

    //批量插入
    //odbc风格
    //预处理语句
    //？相当于 占位符
    query.prepare("insert into shop(id,name,ownername,Rentprice,waterfee,electricityfee,propertyfee,contractId) values(?,?,?,?,?,?,?,?)");
    //给字段设置内容 list
    QVariantList idlist;
    idlist<<"1001"<<"1002"<<"1003";
    QVariantList namelist;
    namelist<<QStringLiteral("商铺一")<<QStringLiteral("商铺二")<<QStringLiteral("商铺三");
    QVariantList ownernamelist;
    ownernamelist<<QStringLiteral("张三")<<QStringLiteral("李四")<<QStringLiteral("王五");
    QVariantList RentPrice;
    RentPrice<<20<<22<<33;

    QVariantList waterfee;
    waterfee<<5<<5<<5;
    QVariantList electricityfee;
    electricityfee<<5<<5<<5;
    QVariantList propertyfee;
    propertyfee<<10<<10<<10;
    QVariantList contractId;
    contractId<<1001<<1002<<1003;

    //给字段绑定相应的值 按顺序绑定
    query.addBindValue(idlist);
    query.addBindValue(namelist);
    query.addBindValue(ownernamelist);
    query.addBindValue(RentPrice);

    query.addBindValue(waterfee);
    query.addBindValue(electricityfee);
    query.addBindValue(propertyfee);
    query.addBindValue(contractId);
    //执行预处理命令
    query.execBatch();
    */

    query.exec("select * from shop");

    while(query.next())
    {
        qDebug()<<query.value(0).toInt()
                <<query.value(1).toString()
                <<query.value(2).toString()
                <<query.value(3).toInt()
                <<query.value(4).toInt()
                <<query.value(5).toInt()
                <<query.value(6).toInt()
                <<query.value(7).toInt();
    }

    //设置模型
    model =new QSqlTableModel(this);
    model->setTable("shop");//指定表

    //把model放在view里面
    ui->tableView->setModel(model);

    //显示model里的数据
    model->select();

    model->setHeaderData(0,Qt::Horizontal,QStringLiteral("商铺ID"));
    model->setHeaderData(1,Qt::Horizontal,QStringLiteral("商铺名称"));
    model->setHeaderData(2,Qt::Horizontal,QStringLiteral("业主姓名"));
    model->setHeaderData(3,Qt::Horizontal,QStringLiteral("商铺租金（万元/月）"));
    model->setHeaderData(4,Qt::Horizontal,QStringLiteral("水费（元）"));
    model->setHeaderData(5,Qt::Horizontal,QStringLiteral("电费（元）"));
    model->setHeaderData(6,Qt::Horizontal,QStringLiteral("物业费（元/月）"));
    model->setHeaderData(7,Qt::Horizontal,QStringLiteral("合同ID"));

    //设置model的编辑模式，手动提交修改
    model->setEditStrategy(QSqlTableModel::OnManualSubmit);

    //ui->tableView->setTextElideMode(QAbstractItemView::NoEditTriggers);
}

ShopDatabase::~ShopDatabase()
{
    delete ui;
}

//添加
void ShopDatabase::on_buttonAdd_clicked()
{
    //添加空记录
    QSqlRecord record=model->record();//获取空记录
    //获取行号
    int row=model->rowCount();
    model->insertRecord(row,record);
}

//确认修改
void ShopDatabase::on_buttonSure_clicked()
{
    model->submitAll();//提交动作
}

//撤销修改
void ShopDatabase::on_buttonCancel_clicked()
{
    model->revertAll();//取消所有动作
    model->submitAll();//提交所有动作
}

//删除
void ShopDatabase::on_buttonDel_clicked()
{
    //获取选中的模型
   QItemSelectionModel *smodel=ui->tableView->selectionModel();
   //取出模型中的索引
   QModelIndexList list=smodel->selectedRows();
   //删除所有选中的行
   for(int i=0;i<list.size();i++)
   {
       model->removeRow(list.at(i).row());
   }

}

//查找
void ShopDatabase::on_buttonFind_clicked()
{
    QString name=ui->lineEdit->text();
    QString str=QString("name='%1'").arg(name);

    model->setFilter(str);
    model->select();
}

//显示所有数据
void ShopDatabase::on_buttonShow_clicked()
{
    model->setTable("shop");//指定表

    //把model放在view里面
    ui->tableView->setModel(model);

    //显示model里的数据
    model->select();

    model->setHeaderData(0,Qt::Horizontal,QStringLiteral("商铺ID"));
    model->setHeaderData(1,Qt::Horizontal,QStringLiteral("商铺名称"));
    model->setHeaderData(2,Qt::Horizontal,QStringLiteral("业主姓名"));
    model->setHeaderData(3,Qt::Horizontal,QStringLiteral("商铺租金（万元/月）"));
    model->setHeaderData(4,Qt::Horizontal,QStringLiteral("水费（元）"));
    model->setHeaderData(5,Qt::Horizontal,QStringLiteral("电费（元）"));
    model->setHeaderData(6,Qt::Horizontal,QStringLiteral("物业费（元/月）"));
    model->setHeaderData(7,Qt::Horizontal,QStringLiteral("合同ID"));
}


