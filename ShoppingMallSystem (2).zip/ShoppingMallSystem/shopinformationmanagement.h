﻿#ifndef SHOPINFORMATIONMANAGEMENT_H
#define SHOPINFORMATIONMANAGEMENT_H

#include <QMainWindow>

namespace Ui {
class ShopInformationManagement;
}

class ShopInformationManagement : public QMainWindow
{
    Q_OBJECT

public:
    explicit ShopInformationManagement(QWidget *parent = nullptr);
    ~ShopInformationManagement();

private slots:
    void receiveDataFromShopDistribution(QString identity);

    void on_pushButton_2_clicked();

    void on_pushButton_clicked();

private:
    Ui::ShopInformationManagement *ui;

    QString shopID;
};

#endif // SHOPINFORMATIONMANAGEMENT_H
