﻿#ifndef SUBLEASE_H
#define SUBLEASE_H

#include <QMainWindow>

namespace Ui {
class Sublease;
}

class Sublease : public QMainWindow
{
    Q_OBJECT

public:
    explicit Sublease(QWidget *parent = nullptr);
    ~Sublease();

private slots:


private:
    Ui::Sublease *ui;
};

#endif // SUBLEASE_H
