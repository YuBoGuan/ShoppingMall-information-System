﻿#include "payment.h"
#include "ui_payment.h"

Payment::Payment(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::Payment)
{
    ui->setupUi(this);
}

Payment::~Payment()
{
    delete ui;
}

//一键支付
void Payment::on_pushButton_clicked()
{
    SuccessfulPaymentPro =new SuccessfulPayment;
    SuccessfulPaymentPro->show();
}

//返回主页
void Payment::on_pushButton_2_clicked()
{
    this->close();
}
