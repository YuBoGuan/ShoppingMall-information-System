﻿#include "successfulpayment.h"
#include "ui_successfulpayment.h"

SuccessfulPayment::SuccessfulPayment(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::SuccessfulPayment)
{
    ui->setupUi(this);
    //固定窗口大小
    this->setFixedSize( this->width (),this->height ());

}

SuccessfulPayment::~SuccessfulPayment()
{
    delete ui;
}

void SuccessfulPayment::on_pushButton_clicked()
{
    this->close();
}
