﻿#ifndef LOGIN_H
#define LOGIN_H

#include <QMainWindow>
#include <QSqlTableModel>
#include "shopowner.h"
#include"companystaff.h"
#include"shopdistribution.h"
namespace Ui {
class login;
}

class login : public QMainWindow
{
    Q_OBJECT

public:
    explicit login(QWidget *parent = nullptr);
    ~login();

private slots:
    void on_pushButton_login_clicked();

    void on_pushButton_register_clicked();

    void on_pushButton_login_register_clicked();

signals:
    void sendDataToOwner(QString data);
    void sendDataToStaff(QString data);
    void sendidToOwner(QString data);


private:
    Ui::login *ui;

    shopOwner *ownerPro;
    companyStaff *staffPro;
    ShopDistribution *ShopDistributionPro;

    //设置模型
    QSqlTableModel *model;
    //选择的操作类型：登录 注册
    QString login_register;
    //选择的身份类型对应的数据库中的表
    QString databaseType;//商铺 业主 公司职员
    QString StaffPost;//公司员工身份
};

#endif // LOGIN_H
