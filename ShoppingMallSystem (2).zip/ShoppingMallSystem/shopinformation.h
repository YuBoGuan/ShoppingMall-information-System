﻿#ifndef SHOPINFORMATION_H
#define SHOPINFORMATION_H

#include <QMainWindow>

namespace Ui {
class ShopInformation;
}

class ShopInformation : public QMainWindow
{
    Q_OBJECT

public:
    explicit ShopInformation(QWidget *parent = nullptr);
    ~ShopInformation();

signals:
    void sendData(QString data);

private slots:
    void  receiveData(QString identity);
    void  receiveshopOwner(QString identity);
    void  receiveDataFromPersonalCenter(QString identity);

    void on_pushButton_2_clicked();

    void on_pushButton_clicked();

private:
    Ui::ShopInformation *ui;

    QString shopId;

    QString ownerid;

};

#endif // SHOPINFORMATION_H
