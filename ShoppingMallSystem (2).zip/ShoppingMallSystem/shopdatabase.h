﻿#ifndef SHOPDATABASE_H
#define SHOPDATABASE_H

#include <QWidget>
#include <QSqlTableModel>
namespace Ui {
class ShopDatabase;
}

class ShopDatabase : public QWidget
{
    Q_OBJECT

public:
    explicit ShopDatabase(QWidget *parent = nullptr);
    ~ShopDatabase();

private slots:
    void on_buttonAdd_clicked();

    void on_buttonDel_clicked();

    void on_buttonSure_clicked();

    void on_buttonCancel_clicked();

    void on_buttonShow_clicked();

    void on_buttonFind_clicked();

private:
    Ui::ShopDatabase *ui;

    //设置模型
    QSqlTableModel *model;

};

#endif // SHOPDATABASE_H
