﻿#include "shopdistribution.h"
#include "ui_shopdistribution.h"
#include"QMessageBox"
#include <QSqlDatabase>
#include <QDebug>
#include <QMessageBox>
#include <QSqlError>
#include <QSqlQuery>//对sql语句进行操作
#include <QVariantList>
#include <QSqlTableModel>
#include <QSqlRecord>
#include <QMenuBar>
#include <QMenu>

ShopDistribution::ShopDistribution(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::ShopDistribution)
{
    ui->setupUi(this);
    //固定窗口大小
    this->setFixedSize( this->width (),this->height ());

    //商铺的四种状态
    //申请状态
    this->ApplicationStatus=":/image/ApplicationStatus.svg";
    //空闲状态
    this->IdleState=":/image/IdleState.svg";
    //转租状态
    this->SubleaseStatus=":/image/SubleaseStatus.svg";
    //占用状态
    this->OccupancyStatus=":/image/OccupancyStatus.svg";

    //添加数据库
    QSqlDatabase db=QSqlDatabase::addDatabase("QSQLITE");

    //连接数据库
    /*
      数据库中的表：
      商铺信息表 shop
      业主信息表 shopOwner
      公司员工表 companyStaff
    */
    db.setDatabaseName("info.db");


    //打开数据库
    if(!db.open())
    {
        QMessageBox::warning(this,QStringLiteral("打开错误"),db.lastError().text());
        return;
    }

    /*ui->pushButton_1->setEnabled(false);
    ui->pushButton_2->setEnabled(false);
    ui->pushButton_3->setEnabled(false);
    ui->pushButton_4->setEnabled(false);
    ui->pushButton_5->setEnabled(false);
    ui->pushButton_6->setEnabled(false);
    ui->pushButton_7->setEnabled(false);
    ui->pushButton_8->setEnabled(false);
    ui->pushButton_9->setEnabled(false);
    ui->pushButton_10->setEnabled(false);
    ui->pushButton_11->setEnabled(false);
    ui->pushButton_12->setEnabled(false);
    ui->pushButton_13->setEnabled(false);
    ui->pushButton_14->setEnabled(false);
    ui->pushButton_15->setEnabled(false);
    ui->pushButton_16->setEnabled(false);
    ui->pushButton_17->setEnabled(false);
    ui->pushButton_18->setEnabled(false);
    ui->pushButton_19->setEnabled(false);
    ui->pushButton_20->setEnabled(false);
    ui->pushButton_21->setEnabled(false);
    ui->pushButton_22->setEnabled(false);
    ui->pushButton_23->setEnabled(false);
    ui->pushButton_24->setEnabled(false);
    ui->pushButton_25->setEnabled(false);
    ui->pushButton_26->setEnabled(false);
    ui->pushButton_27->setEnabled(false);
    ui->pushButton_28->setEnabled(false);
    ui->pushButton_29->setEnabled(false);
    ui->pushButton_30->setEnabled(false);
    ui->pushButton_31->setEnabled(false);
    ui->pushButton_32->setEnabled(false);
    ui->pushButton_33->setEnabled(false);
    ui->pushButton_34->setEnabled(false);
    ui->pushButton_35->setEnabled(false);
    ui->pushButton_36->setEnabled(false);*/
    initTable();
}

ShopDistribution::~ShopDistribution()
{
    delete ui;
}


void ShopDistribution::initTable()
{
    //初始化店铺状态
    QSqlQuery query;
    QString sq0=QString("select * from shop");
    query.exec(sq0);


    query.next();
    if(query.value(0).toInt()==1001)
    {
        QString str;
        //str=QString("border-image: url('%1')").arg(this->OccupancyStatus);

        if(query.value(8)==QStringLiteral("空闲"))
        {
            str=QString("border-image: url('%1')").arg(this->IdleState);
            ui->pushButton_1->setEnabled(true);
        }
        if(query.value(8)==QStringLiteral("申请中"))
            str=QString("border-image: url('%1')").arg(this->ApplicationStatus);
        if(query.value(8)==QStringLiteral("占用"))
            str=QString("border-image: url('%1')").arg(this->OccupancyStatus);
        if(query.value(8)==QStringLiteral("转租"))
        {
            str=QString("border-image: url('%1')").arg(this->SubleaseStatus);
            ui->pushButton_1->setEnabled(true);
        }
        ui->pushButton_1->setStyleSheet(str);
    }

    query.next();
    if(query.value(0).toInt()==1002)
    {
        QString str;
        //str=QString("border-image: url('%1')").arg(this->OccupancyStatus);

        if(query.value(8)==QStringLiteral("空闲"))
        {
            str=QString("border-image: url('%1')").arg(this->IdleState);
            ui->pushButton_2->setEnabled(true);
        }
        if(query.value(8)==QStringLiteral("申请中"))
            str=QString("border-image: url('%1')").arg(this->ApplicationStatus);
        if(query.value(8)==QStringLiteral("占用"))
            str=QString("border-image: url('%1')").arg(this->OccupancyStatus);
        if(query.value(8)==QStringLiteral("转租"))
        {
            str=QString("border-image: url('%1')").arg(this->SubleaseStatus);
            ui->pushButton_2->setEnabled(true);
        }
        ui->pushButton_2->setStyleSheet(str);
    }

    query.next();
    if(query.value(0).toInt()==1003)
    {
        QString str;
        //str=QString("border-image: url('%1')").arg(this->OccupancyStatus);

        if(query.value(8)==QStringLiteral("空闲"))
        {
            str=QString("border-image: url('%1')").arg(this->IdleState);
            ui->pushButton_3->setEnabled(true);
        }
        if(query.value(8)==QStringLiteral("申请中"))
            str=QString("border-image: url('%1')").arg(this->ApplicationStatus);
        if(query.value(8)==QStringLiteral("占用"))
            str=QString("border-image: url('%1')").arg(this->OccupancyStatus);
        if(query.value(8)==QStringLiteral("转租"))
        {
            ui->pushButton_3->setEnabled(true);
            str=QString("border-image: url('%1')").arg(this->SubleaseStatus);
        }
        ui->pushButton_3->setStyleSheet(str);
    }

    query.next();
    if(query.value(0).toInt()==1004)
    {
        QString str;
        //str=QString("border-image: url('%1')").arg(this->OccupancyStatus);

        if(query.value(8)==QStringLiteral("空闲"))
        {
            str=QString("border-image: url('%1')").arg(this->IdleState);
            ui->pushButton_4->setEnabled(true);
        }
        if(query.value(8)==QStringLiteral("申请中"))
            str=QString("border-image: url('%1')").arg(this->ApplicationStatus);
        if(query.value(8)==QStringLiteral("占用"))
            str=QString("border-image: url('%1')").arg(this->OccupancyStatus);
        if(query.value(8)==QStringLiteral("转租"))
        {
            str=QString("border-image: url('%1')").arg(this->SubleaseStatus);
            ui->pushButton_4->setEnabled(true);
        }
        ui->pushButton_4->setStyleSheet(str);
    }

    query.next();
    if(query.value(0).toInt()==1005)
    {
        QString str;
        //str=QString("border-image: url('%1')").arg(this->OccupancyStatus);

        if(query.value(8)==QStringLiteral("空闲"))
        {
            str=QString("border-image: url('%1')").arg(this->IdleState);
            ui->pushButton_5->setEnabled(true);
        }
        if(query.value(8)==QStringLiteral("申请中"))
            str=QString("border-image: url('%1')").arg(this->ApplicationStatus);
        if(query.value(8)==QStringLiteral("占用"))
            str=QString("border-image: url('%1')").arg(this->OccupancyStatus);
        if(query.value(8)==QStringLiteral("转租"))
        {
            str=QString("border-image: url('%1')").arg(this->SubleaseStatus);
            ui->pushButton_5->setEnabled(true);
        }
        ui->pushButton_5->setStyleSheet(str);
    }

    query.next();
    if(query.value(0).toInt()==1006)
    {
        QString str;
        if(query.value(8)==QStringLiteral("空闲"))
        {
            ui->pushButton_6->setEnabled(true);
            str=QString("border-image: url('%1')").arg(this->IdleState);
        }
        if(query.value(8)==QStringLiteral("申请中"))
            str=QString("border-image: url('%1')").arg(this->ApplicationStatus);
        if(query.value(8)==QStringLiteral("占用"))
            str=QString("border-image: url('%1')").arg(this->OccupancyStatus);
        if(query.value(8)==QStringLiteral("转租"))
        {
            str=QString("border-image: url('%1')").arg(this->SubleaseStatus);
            ui->pushButton_6->setEnabled(true);
        }
        ui->pushButton_6->setStyleSheet(str);
    }

    query.next();
    if(query.value(0).toInt()==1007)
    {
        QString str;
        if(query.value(8)==QStringLiteral("空闲"))
        {
            str=QString("border-image: url('%1')").arg(this->IdleState);
            ui->pushButton_7->setEnabled(true);
        }
        if(query.value(8)==QStringLiteral("申请中"))
            str=QString("border-image: url('%1')").arg(this->ApplicationStatus);
        if(query.value(8)==QStringLiteral("占用"))
            str=QString("border-image: url('%1')").arg(this->OccupancyStatus);
        if(query.value(8)==QStringLiteral("转租"))
        {
            str=QString("border-image: url('%1')").arg(this->SubleaseStatus);
            ui->pushButton_7->setEnabled(true);
        }
        ui->pushButton_7->setStyleSheet(str);
    }

    query.next();
    if(query.value(0).toInt()==1008)
    {
        QString str;
        if(query.value(8)==QStringLiteral("空闲"))
        {
            str=QString("border-image: url('%1')").arg(this->IdleState);
            ui->pushButton_8->setEnabled(true);
        }
        if(query.value(8)==QStringLiteral("申请中"))
            str=QString("border-image: url('%1')").arg(this->ApplicationStatus);
        if(query.value(8)==QStringLiteral("占用"))
            str=QString("border-image: url('%1')").arg(this->OccupancyStatus);
        if(query.value(8)==QStringLiteral("转租"))
        {
            str=QString("border-image: url('%1')").arg(this->SubleaseStatus);
            ui->pushButton_8->setEnabled(true);
        }
        ui->pushButton_8->setStyleSheet(str);
    }

    query.next();
    if(query.value(0).toInt()==1009)
    {
        QString str;
        if(query.value(8)==QStringLiteral("空闲"))
        {
            str=QString("border-image: url('%1')").arg(this->IdleState);
            ui->pushButton_9->setEnabled(true);
        }
        if(query.value(8)==QStringLiteral("申请中"))
            str=QString("border-image: url('%1')").arg(this->ApplicationStatus);
        if(query.value(8)==QStringLiteral("占用"))
            str=QString("border-image: url('%1')").arg(this->OccupancyStatus);
        if(query.value(8)==QStringLiteral("转租"))
        {
            str=QString("border-image: url('%1')").arg(this->SubleaseStatus);
            ui->pushButton_9->setEnabled(true);
        }
        ui->pushButton_9->setStyleSheet(str);
    }

    query.next();
    if(query.value(0).toInt()==1010)
    {
        QString str;
        if(query.value(8)==QStringLiteral("空闲"))
        {
            str=QString("border-image: url('%1')").arg(this->IdleState);
            ui->pushButton_10->setEnabled(true);
        }
        if(query.value(8)==QStringLiteral("申请中"))
            str=QString("border-image: url('%1')").arg(this->ApplicationStatus);
        if(query.value(8)==QStringLiteral("占用"))
            str=QString("border-image: url('%1')").arg(this->OccupancyStatus);
        if(query.value(8)==QStringLiteral("转租"))
        {
            str=QString("border-image: url('%1')").arg(this->SubleaseStatus);
            ui->pushButton_10->setEnabled(true);
        }
        ui->pushButton_10->setStyleSheet(str);
    }

    query.next();
    if(query.value(0).toInt()==1011)
    {
        QString str;
        if(query.value(8)==QStringLiteral("空闲"))
        {
            str=QString("border-image: url('%1')").arg(this->IdleState);
            ui->pushButton_11->setEnabled(true);
        }
        if(query.value(8)==QStringLiteral("申请中"))
            str=QString("border-image: url('%1')").arg(this->ApplicationStatus);
        if(query.value(8)==QStringLiteral("占用"))
            str=QString("border-image: url('%1')").arg(this->OccupancyStatus);
        if(query.value(8)==QStringLiteral("转租"))
        {
            str=QString("border-image: url('%1')").arg(this->SubleaseStatus);
            ui->pushButton_11->setEnabled(true);
        }
        ui->pushButton_11->setStyleSheet(str);
    }

    query.next();
    if(query.value(0).toInt()==1012)
    {
        QString str;
        if(query.value(8)==QStringLiteral("空闲"))
        {
            str=QString("border-image: url('%1')").arg(this->IdleState);
            ui->pushButton_12->setEnabled(true);
        }
        if(query.value(8)==QStringLiteral("申请中"))
            str=QString("border-image: url('%1')").arg(this->ApplicationStatus);
        if(query.value(8)==QStringLiteral("占用"))
            str=QString("border-image: url('%1')").arg(this->OccupancyStatus);
        if(query.value(8)==QStringLiteral("转租"))
        {
            str=QString("border-image: url('%1')").arg(this->SubleaseStatus);
            ui->pushButton_12->setEnabled(true);
        }

        ui->pushButton_12->setStyleSheet(str);
    }

    query.next();
    if(query.value(0).toInt()==1013)
    {
        QString str;
        if(query.value(8)==QStringLiteral("空闲"))
        {
            str=QString("border-image: url('%1')").arg(this->IdleState);
            ui->pushButton_13->setEnabled(true);
        }
        if(query.value(8)==QStringLiteral("申请中"))
            str=QString("border-image: url('%1')").arg(this->ApplicationStatus);
        if(query.value(8)==QStringLiteral("占用"))
            str=QString("border-image: url('%1')").arg(this->OccupancyStatus);
        if(query.value(8)==QStringLiteral("转租"))
        {
            str=QString("border-image: url('%1')").arg(this->SubleaseStatus);
            ui->pushButton_13->setEnabled(true);
        }
        ui->pushButton_13->setStyleSheet(str);
    }

    query.next();
    if(query.value(0).toInt()==1014)
    {
        QString str;
        if(query.value(8)==QStringLiteral("空闲"))
        {
            str=QString("border-image: url('%1')").arg(this->IdleState);
            ui->pushButton_14->setEnabled(true);
        }
        if(query.value(8)==QStringLiteral("申请中"))
            str=QString("border-image: url('%1')").arg(this->ApplicationStatus);
        if(query.value(8)==QStringLiteral("占用"))
            str=QString("border-image: url('%1')").arg(this->OccupancyStatus);
        if(query.value(8)==QStringLiteral("转租"))
        {
            str=QString("border-image: url('%1')").arg(this->SubleaseStatus);
            ui->pushButton_14->setEnabled(true);
        }
        ui->pushButton_14->setStyleSheet(str);
    }

    query.next();
    if(query.value(0).toInt()==1015)
    {
        QString str;
        if(query.value(8)==QStringLiteral("空闲"))
        {
            str=QString("border-image: url('%1')").arg(this->IdleState);
            ui->pushButton_15->setEnabled(true);
        }
        if(query.value(8)==QStringLiteral("申请中"))
            str=QString("border-image: url('%1')").arg(this->ApplicationStatus);
        if(query.value(8)==QStringLiteral("占用"))
            str=QString("border-image: url('%1')").arg(this->OccupancyStatus);
        if(query.value(8)==QStringLiteral("转租"))
        {
            str=QString("border-image: url('%1')").arg(this->SubleaseStatus);
            ui->pushButton_15->setEnabled(true);
        }
        ui->pushButton_15->setStyleSheet(str);
    }

    query.next();
    if(query.value(0).toInt()==1016)
    {
        QString str;
        if(query.value(8)==QStringLiteral("空闲"))
        {
            str=QString("border-image: url('%1')").arg(this->IdleState);
            ui->pushButton_16->setEnabled(true);
        }
        if(query.value(8)==QStringLiteral("申请中"))
            str=QString("border-image: url('%1')").arg(this->ApplicationStatus);
        if(query.value(8)==QStringLiteral("占用"))
            str=QString("border-image: url('%1')").arg(this->OccupancyStatus);
        if(query.value(8)==QStringLiteral("转租"))
        {
            str=QString("border-image: url('%1')").arg(this->SubleaseStatus);
            ui->pushButton_16->setEnabled(true);
        }

        ui->pushButton_16->setStyleSheet(str);
    }

    query.next();
    if(query.value(0).toInt()==1017)
    {
        QString str;
        if(query.value(8)==QStringLiteral("空闲"))
        {
            str=QString("border-image: url('%1')").arg(this->IdleState);
            ui->pushButton_17->setEnabled(true);
        }
        if(query.value(8)==QStringLiteral("申请中"))
            str=QString("border-image: url('%1')").arg(this->ApplicationStatus);
        if(query.value(8)==QStringLiteral("占用"))
            str=QString("border-image: url('%1')").arg(this->OccupancyStatus);
        if(query.value(8)==QStringLiteral("转租"))
        {
            str=QString("border-image: url('%1')").arg(this->SubleaseStatus);
            ui->pushButton_17->setEnabled(true);
        }
        ui->pushButton_17->setStyleSheet(str);
    }

    query.next();
    if(query.value(0).toInt()==1018)
    {
        QString str;
        if(query.value(8)==QStringLiteral("空闲"))
        {
            str=QString("border-image: url('%1')").arg(this->IdleState);
            ui->pushButton_18->setEnabled(true);
        }
        if(query.value(8)==QStringLiteral("申请中"))
            str=QString("border-image: url('%1')").arg(this->ApplicationStatus);
        if(query.value(8)==QStringLiteral("占用"))
            str=QString("border-image: url('%1')").arg(this->OccupancyStatus);
        if(query.value(8)==QStringLiteral("转租"))
        {
            str=QString("border-image: url('%1')").arg(this->SubleaseStatus);
            ui->pushButton_18->setEnabled(true);
        }
        ui->pushButton_18->setStyleSheet(str);
    }

    query.next();
    if(query.value(0).toInt()==1019)
    {
        QString str;
        if(query.value(8)==QStringLiteral("空闲"))
        {
            str=QString("border-image: url('%1')").arg(this->IdleState);
            ui->pushButton_19->setEnabled(true);
        }
        if(query.value(8)==QStringLiteral("申请中"))
            str=QString("border-image: url('%1')").arg(this->ApplicationStatus);
        if(query.value(8)==QStringLiteral("占用"))
            str=QString("border-image: url('%1')").arg(this->OccupancyStatus);
        if(query.value(8)==QStringLiteral("转租"))
        {
            str=QString("border-image: url('%1')").arg(this->SubleaseStatus);
            ui->pushButton_19->setEnabled(true);
        }
        ui->pushButton_19->setStyleSheet(str);
    }

    query.next();
    if(query.value(0).toInt()==1020)
    {
        QString str;
        if(query.value(8)==QStringLiteral("空闲"))
        {
            str=QString("border-image: url('%1')").arg(this->IdleState);
            ui->pushButton_20->setEnabled(true);
        }
        if(query.value(8)==QStringLiteral("申请中"))
            str=QString("border-image: url('%1')").arg(this->ApplicationStatus);
        if(query.value(8)==QStringLiteral("占用"))
            str=QString("border-image: url('%1')").arg(this->OccupancyStatus);
        if(query.value(8)==QStringLiteral("转租"))
        {
            str=QString("border-image: url('%1')").arg(this->SubleaseStatus);
            ui->pushButton_20->setEnabled(true);
        }
        ui->pushButton_20->setStyleSheet(str);
    }

    query.next();
    if(query.value(0).toInt()==1021)
    {
        QString str;
        if(query.value(8)==QStringLiteral("空闲"))
        {
            str=QString("border-image: url('%1')").arg(this->IdleState);
            ui->pushButton_21->setEnabled(true);
        }
        if(query.value(8)==QStringLiteral("申请中"))
            str=QString("border-image: url('%1')").arg(this->ApplicationStatus);
        if(query.value(8)==QStringLiteral("占用"))
            str=QString("border-image: url('%1')").arg(this->OccupancyStatus);
        if(query.value(8)==QStringLiteral("转租"))
        {
            str=QString("border-image: url('%1')").arg(this->SubleaseStatus);
            ui->pushButton_21->setEnabled(true);
        }
        ui->pushButton_21->setStyleSheet(str);
    }

    query.next();
    if(query.value(0).toInt()==1022)
    {
        QString str;
        if(query.value(8)==QStringLiteral("空闲"))
        {
            str=QString("border-image: url('%1')").arg(this->IdleState);
            ui->pushButton_22->setEnabled(true);
        }
        if(query.value(8)==QStringLiteral("申请中"))
            str=QString("border-image: url('%1')").arg(this->ApplicationStatus);
        if(query.value(8)==QStringLiteral("占用"))
            str=QString("border-image: url('%1')").arg(this->OccupancyStatus);
        if(query.value(8)==QStringLiteral("转租"))
        {
            str=QString("border-image: url('%1')").arg(this->SubleaseStatus);
            ui->pushButton_22->setEnabled(true);
        }
        ui->pushButton_22->setStyleSheet(str);
    }

    query.next();
    if(query.value(0).toInt()==1023)
    {
        QString str;
        if(query.value(8)==QStringLiteral("空闲"))
        {
            str=QString("border-image: url('%1')").arg(this->IdleState);
            ui->pushButton_23->setEnabled(true);
        }
        if(query.value(8)==QStringLiteral("申请中"))
            str=QString("border-image: url('%1')").arg(this->ApplicationStatus);
        if(query.value(8)==QStringLiteral("占用"))
            str=QString("border-image: url('%1')").arg(this->OccupancyStatus);
        if(query.value(8)==QStringLiteral("转租"))
        {
            str=QString("border-image: url('%1')").arg(this->SubleaseStatus);
            ui->pushButton_23->setEnabled(true);
        }
        ui->pushButton_23->setStyleSheet(str);
    }

    query.next();
    if(query.value(0).toInt()==1024)
    {
        QString str;
        if(query.value(8)==QStringLiteral("空闲"))
        {
            str=QString("border-image: url('%1')").arg(this->IdleState);
            ui->pushButton_24->setEnabled(true);
        }
        if(query.value(8)==QStringLiteral("申请中"))
            str=QString("border-image: url('%1')").arg(this->ApplicationStatus);
        if(query.value(8)==QStringLiteral("占用"))
            str=QString("border-image: url('%1')").arg(this->OccupancyStatus);
        if(query.value(8)==QStringLiteral("转租"))
        {
            str=QString("border-image: url('%1')").arg(this->SubleaseStatus);
            ui->pushButton_24->setEnabled(true);
        }
        ui->pushButton_24->setStyleSheet(str);
    }

    query.next();
    if(query.value(0).toInt()==1025)
    {
        QString str;
        if(query.value(8)==QStringLiteral("空闲"))
        {
            str=QString("border-image: url('%1')").arg(this->IdleState);
            ui->pushButton_25->setEnabled(true);
        }
        if(query.value(8)==QStringLiteral("申请中"))
            str=QString("border-image: url('%1')").arg(this->ApplicationStatus);
        if(query.value(8)==QStringLiteral("占用"))
            str=QString("border-image: url('%1')").arg(this->OccupancyStatus);
        if(query.value(8)==QStringLiteral("转租"))
        {
            str=QString("border-image: url('%1')").arg(this->SubleaseStatus);
            ui->pushButton_25->setEnabled(true);
        }
        ui->pushButton_25->setStyleSheet(str);
    }

    query.next();
    if(query.value(0).toInt()==1026)
    {
        QString str;
        if(query.value(8)==QStringLiteral("空闲"))
        {
            str=QString("border-image: url('%1')").arg(this->IdleState);
            ui->pushButton_26->setEnabled(true);
        }
        if(query.value(8)==QStringLiteral("申请中"))
            str=QString("border-image: url('%1')").arg(this->ApplicationStatus);
        if(query.value(8)==QStringLiteral("占用"))
            str=QString("border-image: url('%1')").arg(this->OccupancyStatus);
        if(query.value(8)==QStringLiteral("转租"))
        {
            str=QString("border-image: url('%1')").arg(this->SubleaseStatus);
            ui->pushButton_26->setEnabled(true);
        }
        ui->pushButton_26->setStyleSheet(str);
    }

    query.next();
    if(query.value(0).toInt()==1027)
    {
        QString str;
        if(query.value(8)==QStringLiteral("空闲"))
        {
            str=QString("border-image: url('%1')").arg(this->IdleState);
            ui->pushButton_27->setEnabled(true);
        }
        if(query.value(8)==QStringLiteral("申请中"))
            str=QString("border-image: url('%1')").arg(this->ApplicationStatus);
        if(query.value(8)==QStringLiteral("占用"))
            str=QString("border-image: url('%1')").arg(this->OccupancyStatus);
        if(query.value(8)==QStringLiteral("转租"))
        {
            str=QString("border-image: url('%1')").arg(this->SubleaseStatus);
            ui->pushButton_27->setEnabled(true);
        }
        ui->pushButton_27->setStyleSheet(str);
    }

    query.next();
    if(query.value(0).toInt()==1028)
    {
        QString str;
        if(query.value(8)==QStringLiteral("空闲"))
        {
            str=QString("border-image: url('%1')").arg(this->IdleState);
            ui->pushButton_28->setEnabled(true);
        }
        if(query.value(8)==QStringLiteral("申请中"))
            str=QString("border-image: url('%1')").arg(this->ApplicationStatus);
        if(query.value(8)==QStringLiteral("占用"))
            str=QString("border-image: url('%1')").arg(this->OccupancyStatus);
        if(query.value(8)==QStringLiteral("转租"))
        {
            str=QString("border-image: url('%1')").arg(this->SubleaseStatus);
            ui->pushButton_28->setEnabled(true);
        }
        ui->pushButton_28->setStyleSheet(str);
    }

    query.next();
    if(query.value(0).toInt()==1029)
    {
        QString str;
        if(query.value(8)==QStringLiteral("空闲"))
        {
            str=QString("border-image: url('%1')").arg(this->IdleState);
            ui->pushButton_29->setEnabled(true);
        }
        if(query.value(8)==QStringLiteral("申请中"))
            str=QString("border-image: url('%1')").arg(this->ApplicationStatus);
        if(query.value(8)==QStringLiteral("占用"))
            str=QString("border-image: url('%1')").arg(this->OccupancyStatus);
        if(query.value(8)==QStringLiteral("转租"))
        {
            str=QString("border-image: url('%1')").arg(this->SubleaseStatus);
            ui->pushButton_29->setEnabled(true);
        }
        ui->pushButton_29->setStyleSheet(str);
    }

    query.next();
    if(query.value(0).toInt()==1030)
    {
        QString str;
        if(query.value(8)==QStringLiteral("空闲"))
        {
            str=QString("border-image: url('%1')").arg(this->IdleState);
            ui->pushButton_30->setEnabled(true);
        }
        if(query.value(8)==QStringLiteral("申请中"))
            str=QString("border-image: url('%1')").arg(this->ApplicationStatus);
        if(query.value(8)==QStringLiteral("占用"))
            str=QString("border-image: url('%1')").arg(this->OccupancyStatus);
        if(query.value(8)==QStringLiteral("转租"))
        {
            str=QString("border-image: url('%1')").arg(this->SubleaseStatus);
            ui->pushButton_30->setEnabled(true);
        }
        ui->pushButton_30->setStyleSheet(str);
    }

    query.next();
    if(query.value(0).toInt()==1031)
    {
        QString str;
        if(query.value(8)==QStringLiteral("空闲"))
        {
            str=QString("border-image: url('%1')").arg(this->IdleState);
            ui->pushButton_31->setEnabled(true);
        }
        if(query.value(8)==QStringLiteral("申请中"))
            str=QString("border-image: url('%1')").arg(this->ApplicationStatus);
        if(query.value(8)==QStringLiteral("占用"))
            str=QString("border-image: url('%1')").arg(this->OccupancyStatus);
        if(query.value(8)==QStringLiteral("转租"))
        {
            str=QString("border-image: url('%1')").arg(this->SubleaseStatus);
            ui->pushButton_31->setEnabled(true);
        }
        ui->pushButton_31->setStyleSheet(str);
    }

    query.next();
    if(query.value(0).toInt()==1032)
    {
        QString str;
        if(query.value(8)==QStringLiteral("空闲"))
        {
            str=QString("border-image: url('%1')").arg(this->IdleState);
            ui->pushButton_32->setEnabled(true);
        }
        if(query.value(8)==QStringLiteral("申请中"))
            str=QString("border-image: url('%1')").arg(this->ApplicationStatus);
        if(query.value(8)==QStringLiteral("占用"))
            str=QString("border-image: url('%1')").arg(this->OccupancyStatus);
        if(query.value(8)==QStringLiteral("转租"))
        {
            str=QString("border-image: url('%1')").arg(this->SubleaseStatus);
            ui->pushButton_32->setEnabled(true);
        }
        ui->pushButton_32->setStyleSheet(str);
    }

    query.next();
    if(query.value(0).toInt()==1033)
    {
        QString str;
        if(query.value(8)==QStringLiteral("空闲"))
        {
            str=QString("border-image: url('%1')").arg(this->IdleState);
            ui->pushButton_33->setEnabled(true);
        }
        if(query.value(8)==QStringLiteral("申请中"))
            str=QString("border-image: url('%1')").arg(this->ApplicationStatus);
        if(query.value(8)==QStringLiteral("占用"))
            str=QString("border-image: url('%1')").arg(this->OccupancyStatus);
        if(query.value(8)==QStringLiteral("转租"))
        {
            str=QString("border-image: url('%1')").arg(this->SubleaseStatus);
            ui->pushButton_33->setEnabled(true);
        }
        ui->pushButton_33->setStyleSheet(str);
    }

    query.next();
    if(query.value(0).toInt()==1034)
    {
        QString str;
        if(query.value(8)==QStringLiteral("空闲"))
        {
            str=QString("border-image: url('%1')").arg(this->IdleState);
            ui->pushButton_34->setEnabled(true);
        }
        if(query.value(8)==QStringLiteral("申请中"))
            str=QString("border-image: url('%1')").arg(this->ApplicationStatus);
        if(query.value(8)==QStringLiteral("占用"))
            str=QString("border-image: url('%1')").arg(this->OccupancyStatus);
        if(query.value(8)==QStringLiteral("转租"))
        {
            str=QString("border-image: url('%1')").arg(this->SubleaseStatus);
            ui->pushButton_34->setEnabled(true);
        }
        ui->pushButton_34->setStyleSheet(str);
    }

    query.next();
    if(query.value(0).toInt()==1035)
    {
        QString str;
        if(query.value(8)==QStringLiteral("空闲"))
        {
            str=QString("border-image: url('%1')").arg(this->IdleState);
            ui->pushButton_35->setEnabled(true);
        }
        if(query.value(8)==QStringLiteral("申请中"))
            str=QString("border-image: url('%1')").arg(this->ApplicationStatus);
        if(query.value(8)==QStringLiteral("占用"))
            str=QString("border-image: url('%1')").arg(this->OccupancyStatus);
        if(query.value(8)==QStringLiteral("转租"))
        {
            str=QString("border-image: url('%1')").arg(this->SubleaseStatus);
            ui->pushButton_35->setEnabled(true);
        }
        ui->pushButton_35->setStyleSheet(str);
    }

    query.next();
    if(query.value(0).toInt()==1036)
    {
        QString str;
        if(query.value(8)==QStringLiteral("空闲"))
        {
            str=QString("border-image: url('%1')").arg(this->IdleState);
            ui->pushButton_36->setEnabled(true);
        }
        if(query.value(8)==QStringLiteral("申请中"))
            str=QString("border-image: url('%1')").arg(this->ApplicationStatus);
        if(query.value(8)==QStringLiteral("占用"))
            str=QString("border-image: url('%1')").arg(this->OccupancyStatus);
        if(query.value(8)==QStringLiteral("转租"))
        {
            str=QString("border-image: url('%1')").arg(this->SubleaseStatus);
            ui->pushButton_36->setEnabled(true);
        }
        ui->pushButton_36->setStyleSheet(str);
    }
}

void ShopDistribution::on_pushButton_1_clicked()
{
    if(this->operatingType==1)
    {
        ShopInformationPro =new ShopInformation;
        connect(this,SIGNAL(sendData(QString)),ShopInformationPro,SLOT(receiveData(QString)));
        connect(ShopInformationPro,SIGNAL(sendData(QString)),this,SLOT(receiveData(QString)));
        connect(this,SIGNAL(sendshopOwner(QString)),ShopInformationPro,SLOT(receiveshopOwner(QString)));
        emit sendData("1001");
        emit sendshopOwner(this->ownerid);
        ShopInformationPro->show();
    }
    if(this->operatingType==2)
    {
        ShopInformationManagementPro =new ShopInformationManagement;
        connect(this,SIGNAL(sendDataToShopInformationManagement(QString)),ShopInformationManagementPro,SLOT(receiveDataFromShopDistribution(QString)));
        emit sendDataToShopInformationManagement("1001");
        ShopInformationManagementPro->show();
    }

}

void ShopDistribution::receiveDataFromshopOwner(QString identity)
{
    this->ownerid=identity;
    this->operatingType=1;
}

void ShopDistribution::receiveDataFromcompanyStaff(QString identity)
{
    //QMessageBox::warning(this,"warning",this->ownerid,QMessageBox::Yes,QMessageBox::No);
    this->setStyleSheet("#ShopDistribution{border-image: url(':/image/ShopDistribution2.JPG')}");
    this->operatingType=2;
}

void  ShopDistribution::receiveData(QString identity)
{
    QString str;
    str=QString("border-image: url('%1')").arg(this->ApplicationStatus);
    //QMessageBox::warning(this,"warning",this->ownerid,QMessageBox::Yes,QMessageBox::No);
    QSqlQuery query;
    QString sq0=QString("update shop set state='%1' where id='%2'").arg(QStringLiteral("申请中")).arg(identity);
    query.exec(sq0);

    if(identity.toInt()==1001)
        ui->pushButton_1->setStyleSheet(str);
    if(identity.toInt()==1002)
        ui->pushButton_2->setStyleSheet(str);
    if(identity.toInt()==1003)
        ui->pushButton_3->setStyleSheet(str);
    if(identity.toInt()==1004)
        ui->pushButton_4->setStyleSheet(str);
    if(identity.toInt()==1005)
        ui->pushButton_5->setStyleSheet(str);
    if(identity.toInt()==1006)
        ui->pushButton_6->setStyleSheet(str);
    if(identity.toInt()==1007)
        ui->pushButton_7->setStyleSheet(str);
    if(identity.toInt()==1008)
        ui->pushButton_8->setStyleSheet(str);
    if(identity.toInt()==1009)
        ui->pushButton_9->setStyleSheet(str);
    if(identity.toInt()==1010)
        ui->pushButton_10->setStyleSheet(str);
    if(identity.toInt()==1011)
        ui->pushButton_11->setStyleSheet(str);
    if(identity.toInt()==1012)
        ui->pushButton_12->setStyleSheet(str);
    if(identity.toInt()==1013)
        ui->pushButton_13->setStyleSheet(str);
    if(identity.toInt()==1014)
        ui->pushButton_14->setStyleSheet(str);
    if(identity.toInt()==1015)
        ui->pushButton_15->setStyleSheet(str);
    if(identity.toInt()==1016)
        ui->pushButton_16->setStyleSheet(str);
    if(identity.toInt()==1017)
        ui->pushButton_17->setStyleSheet(str);
    if(identity.toInt()==1018)
        ui->pushButton_18->setStyleSheet(str);
    if(identity.toInt()==1019)
        ui->pushButton_19->setStyleSheet(str);
    if(identity.toInt()==1020)
        ui->pushButton_20->setStyleSheet(str);
    if(identity.toInt()==1021)
        ui->pushButton_21->setStyleSheet(str);
    if(identity.toInt()==1022)
        ui->pushButton_22->setStyleSheet(str);
    if(identity.toInt()==1023)
        ui->pushButton_23->setStyleSheet(str);
    if(identity.toInt()==1024)
        ui->pushButton_24->setStyleSheet(str);
    if(identity.toInt()==1025)
        ui->pushButton_25->setStyleSheet(str);
    if(identity.toInt()==1026)
        ui->pushButton_26->setStyleSheet(str);
    if(identity.toInt()==1027)
        ui->pushButton_27->setStyleSheet(str);
    if(identity.toInt()==1028)
        ui->pushButton_28->setStyleSheet(str);
    if(identity.toInt()==1029)
        ui->pushButton_29->setStyleSheet(str);
    if(identity.toInt()==1030)
        ui->pushButton_30->setStyleSheet(str);
    if(identity.toInt()==1031)
        ui->pushButton_31->setStyleSheet(str);
    if(identity.toInt()==1032)
        ui->pushButton_32->setStyleSheet(str);
    if(identity.toInt()==1033)
        ui->pushButton_33->setStyleSheet(str);
    if(identity.toInt()==1034)
        ui->pushButton_34->setStyleSheet(str);
    if(identity.toInt()==1035)
        ui->pushButton_35->setStyleSheet(str);
    if(identity.toInt()==1036)
        ui->pushButton_36->setStyleSheet(str);

}

void ShopDistribution::on_pushButton_2_clicked()
{
    ShopInformationPro =new ShopInformation;
    connect(this,SIGNAL(sendData(QString)),ShopInformationPro,SLOT(receiveData(QString)));
    connect(ShopInformationPro,SIGNAL(sendData(QString)),this,SLOT(receiveData(QString)));
    connect(this,SIGNAL(sendshopOwner(QString)),ShopInformationPro,SLOT(receiveshopOwner(QString)));
    emit sendData("1002");
    emit sendshopOwner(this->ownerid);
    ShopInformationPro->show();
}

void ShopDistribution::on_pushButton_3_clicked()
{
    ShopInformationPro =new ShopInformation;
    connect(this,SIGNAL(sendData(QString)),ShopInformationPro,SLOT(receiveData(QString)));
    connect(ShopInformationPro,SIGNAL(sendData(QString)),this,SLOT(receiveData(QString)));
    connect(this,SIGNAL(sendshopOwner(QString)),ShopInformationPro,SLOT(receiveshopOwner(QString)));
    emit sendData("1003");
    emit sendshopOwner(this->ownerid);
    ShopInformationPro->show();
}

void ShopDistribution::on_pushButton_4_clicked()
{
    ShopInformationPro =new ShopInformation;
    connect(this,SIGNAL(sendData(QString)),ShopInformationPro,SLOT(receiveData(QString)));
    connect(ShopInformationPro,SIGNAL(sendData(QString)),this,SLOT(receiveData(QString)));
    connect(this,SIGNAL(sendshopOwner(QString)),ShopInformationPro,SLOT(receiveshopOwner(QString)));
    emit sendData("1004");
    emit sendshopOwner(this->ownerid);
    ShopInformationPro->show();
}

void ShopDistribution::on_pushButton_5_clicked()
{
    ShopInformationPro =new ShopInformation;
    connect(this,SIGNAL(sendData(QString)),ShopInformationPro,SLOT(receiveData(QString)));
    connect(ShopInformationPro,SIGNAL(sendData(QString)),this,SLOT(receiveData(QString)));
    connect(this,SIGNAL(sendshopOwner(QString)),ShopInformationPro,SLOT(receiveshopOwner(QString)));
    emit sendData("1005");
    emit sendshopOwner(this->ownerid);
    ShopInformationPro->show();
}

void ShopDistribution::on_pushButton_6_clicked()
{
    //QMessageBox::warning(this,"warning",QStringLiteral("选择商铺！ "),QMessageBox::Yes,QMessageBox::No);
    //ui->pushButton->setIcon(QIcon("://image/OccupancyStatus.svg"));
    //ui->pushButton->setStyleSheet("border-image: url(:/image/OccupancyStatus.svg)");
    ShopInformationPro =new ShopInformation;
    connect(this,SIGNAL(sendData(QString)),ShopInformationPro,SLOT(receiveData(QString)));
    connect(ShopInformationPro,SIGNAL(sendData(QString)),this,SLOT(receiveData(QString)));
    connect(this,SIGNAL(sendshopOwner(QString)),ShopInformationPro,SLOT(receiveshopOwner(QString)));
    emit sendData("1006");
    emit sendshopOwner(this->ownerid);
    ShopInformationPro->show();
}

void ShopDistribution::on_pushButton_7_clicked()
{
    ShopInformationPro =new ShopInformation;
    connect(this,SIGNAL(sendData(QString)),ShopInformationPro,SLOT(receiveData(QString)));
    connect(ShopInformationPro,SIGNAL(sendData(QString)),this,SLOT(receiveData(QString)));
    connect(this,SIGNAL(sendshopOwner(QString)),ShopInformationPro,SLOT(receiveshopOwner(QString)));
    emit sendData("1007");
    emit sendshopOwner(this->ownerid);
    ShopInformationPro->show();
}

void ShopDistribution::on_pushButton_8_clicked()
{
    ShopInformationPro =new ShopInformation;
    connect(this,SIGNAL(sendData(QString)),ShopInformationPro,SLOT(receiveData(QString)));
    connect(ShopInformationPro,SIGNAL(sendData(QString)),this,SLOT(receiveData(QString)));
    connect(this,SIGNAL(sendshopOwner(QString)),ShopInformationPro,SLOT(receiveshopOwner(QString)));
    emit sendData("1008");
    emit sendshopOwner(this->ownerid);
    ShopInformationPro->show();
}

void ShopDistribution::on_pushButton_9_clicked()
{
    ShopInformationPro =new ShopInformation;
    connect(this,SIGNAL(sendData(QString)),ShopInformationPro,SLOT(receiveData(QString)));
    connect(ShopInformationPro,SIGNAL(sendData(QString)),this,SLOT(receiveData(QString)));
    connect(this,SIGNAL(sendshopOwner(QString)),ShopInformationPro,SLOT(receiveshopOwner(QString)));
    emit sendData("1009");
    emit sendshopOwner(this->ownerid);
    ShopInformationPro->show();
}

void ShopDistribution::on_pushButton_10_clicked()
{
    ShopInformationPro =new ShopInformation;
    connect(this,SIGNAL(sendData(QString)),ShopInformationPro,SLOT(receiveData(QString)));
    connect(ShopInformationPro,SIGNAL(sendData(QString)),this,SLOT(receiveData(QString)));
    connect(this,SIGNAL(sendshopOwner(QString)),ShopInformationPro,SLOT(receiveshopOwner(QString)));
    emit sendData("1010");
    emit sendshopOwner(this->ownerid);
    ShopInformationPro->show();
}

void ShopDistribution::on_pushButton_11_clicked()
{
    ShopInformationPro =new ShopInformation;
    connect(this,SIGNAL(sendData(QString)),ShopInformationPro,SLOT(receiveData(QString)));
    connect(ShopInformationPro,SIGNAL(sendData(QString)),this,SLOT(receiveData(QString)));
    connect(this,SIGNAL(sendshopOwner(QString)),ShopInformationPro,SLOT(receiveshopOwner(QString)));
    emit sendData("1011");
    emit sendshopOwner(this->ownerid);
    ShopInformationPro->show();
}

void ShopDistribution::on_pushButton_12_clicked()
{
    ShopInformationPro =new ShopInformation;
    connect(this,SIGNAL(sendData(QString)),ShopInformationPro,SLOT(receiveData(QString)));
    connect(ShopInformationPro,SIGNAL(sendData(QString)),this,SLOT(receiveData(QString)));
    connect(this,SIGNAL(sendshopOwner(QString)),ShopInformationPro,SLOT(receiveshopOwner(QString)));
    emit sendData("1012");
    emit sendshopOwner(this->ownerid);
    ShopInformationPro->show();
}

void ShopDistribution::on_pushButton_13_clicked()
{
    ShopInformationPro =new ShopInformation;
    connect(this,SIGNAL(sendData(QString)),ShopInformationPro,SLOT(receiveData(QString)));
    connect(ShopInformationPro,SIGNAL(sendData(QString)),this,SLOT(receiveData(QString)));
    connect(this,SIGNAL(sendshopOwner(QString)),ShopInformationPro,SLOT(receiveshopOwner(QString)));
    emit sendData("1013");
    emit sendshopOwner(this->ownerid);
    ShopInformationPro->show();
}

void ShopDistribution::on_pushButton_14_clicked()
{
    ShopInformationPro =new ShopInformation;
    connect(this,SIGNAL(sendData(QString)),ShopInformationPro,SLOT(receiveData(QString)));
    connect(ShopInformationPro,SIGNAL(sendData(QString)),this,SLOT(receiveData(QString)));
    connect(this,SIGNAL(sendshopOwner(QString)),ShopInformationPro,SLOT(receiveshopOwner(QString)));
    emit sendData("1014");
    emit sendshopOwner(this->ownerid);
    ShopInformationPro->show();
}

void ShopDistribution::on_pushButton_15_clicked()
{
    ShopInformationPro =new ShopInformation;
    connect(this,SIGNAL(sendData(QString)),ShopInformationPro,SLOT(receiveData(QString)));
    connect(ShopInformationPro,SIGNAL(sendData(QString)),this,SLOT(receiveData(QString)));
    connect(this,SIGNAL(sendshopOwner(QString)),ShopInformationPro,SLOT(receiveshopOwner(QString)));
    emit sendData("1015");
    emit sendshopOwner(this->ownerid);
    ShopInformationPro->show();
}

void ShopDistribution::on_pushButton_16_clicked()
{
    ShopInformationPro =new ShopInformation;
    connect(this,SIGNAL(sendData(QString)),ShopInformationPro,SLOT(receiveData(QString)));
    connect(ShopInformationPro,SIGNAL(sendData(QString)),this,SLOT(receiveData(QString)));
    connect(this,SIGNAL(sendshopOwner(QString)),ShopInformationPro,SLOT(receiveshopOwner(QString)));
    emit sendData("1016");
    emit sendshopOwner(this->ownerid);
    ShopInformationPro->show();
}


void ShopDistribution::on_pushButton_17_clicked()
{
    ShopInformationPro =new ShopInformation;
    connect(this,SIGNAL(sendData(QString)),ShopInformationPro,SLOT(receiveData(QString)));
    connect(ShopInformationPro,SIGNAL(sendData(QString)),this,SLOT(receiveData(QString)));
    connect(this,SIGNAL(sendshopOwner(QString)),ShopInformationPro,SLOT(receiveshopOwner(QString)));
    emit sendData("1017");
    emit sendshopOwner(this->ownerid);
    ShopInformationPro->show();
}

void ShopDistribution::on_pushButton_18_clicked()
{
    ShopInformationPro =new ShopInformation;
    connect(this,SIGNAL(sendData(QString)),ShopInformationPro,SLOT(receiveData(QString)));
    connect(ShopInformationPro,SIGNAL(sendData(QString)),this,SLOT(receiveData(QString)));
    connect(this,SIGNAL(sendshopOwner(QString)),ShopInformationPro,SLOT(receiveshopOwner(QString)));
    emit sendData("1018");
    emit sendshopOwner(this->ownerid);
    ShopInformationPro->show();
}

void ShopDistribution::on_pushButton_19_clicked()
{
    ShopInformationPro =new ShopInformation;
    connect(this,SIGNAL(sendData(QString)),ShopInformationPro,SLOT(receiveData(QString)));
    connect(ShopInformationPro,SIGNAL(sendData(QString)),this,SLOT(receiveData(QString)));
    connect(this,SIGNAL(sendshopOwner(QString)),ShopInformationPro,SLOT(receiveshopOwner(QString)));
    emit sendData("1019");
    emit sendshopOwner(this->ownerid);
    ShopInformationPro->show();
}

void ShopDistribution::on_pushButton_20_clicked()
{
    ShopInformationPro =new ShopInformation;
    connect(this,SIGNAL(sendData(QString)),ShopInformationPro,SLOT(receiveData(QString)));
    connect(ShopInformationPro,SIGNAL(sendData(QString)),this,SLOT(receiveData(QString)));
    connect(this,SIGNAL(sendshopOwner(QString)),ShopInformationPro,SLOT(receiveshopOwner(QString)));
    emit sendData("1020");
    emit sendshopOwner(this->ownerid);
    ShopInformationPro->show();
}

void ShopDistribution::on_pushButton_21_clicked()
{
    ShopInformationPro =new ShopInformation;
    connect(this,SIGNAL(sendData(QString)),ShopInformationPro,SLOT(receiveData(QString)));
    connect(ShopInformationPro,SIGNAL(sendData(QString)),this,SLOT(receiveData(QString)));
    connect(this,SIGNAL(sendshopOwner(QString)),ShopInformationPro,SLOT(receiveshopOwner(QString)));
    emit sendData("1021");
    emit sendshopOwner(this->ownerid);
    ShopInformationPro->show();
}

void ShopDistribution::on_pushButton_22_clicked()
{
    ShopInformationPro =new ShopInformation;
    connect(this,SIGNAL(sendData(QString)),ShopInformationPro,SLOT(receiveData(QString)));
    connect(ShopInformationPro,SIGNAL(sendData(QString)),this,SLOT(receiveData(QString)));
    connect(this,SIGNAL(sendshopOwner(QString)),ShopInformationPro,SLOT(receiveshopOwner(QString)));
    emit sendData("1022");
    ShopInformationPro->show();
}

void ShopDistribution::on_pushButton_23_clicked()
{
    ShopInformationPro =new ShopInformation;
    connect(this,SIGNAL(sendData(QString)),ShopInformationPro,SLOT(receiveData(QString)));
    connect(ShopInformationPro,SIGNAL(sendData(QString)),this,SLOT(receiveData(QString)));
    connect(this,SIGNAL(sendshopOwner(QString)),ShopInformationPro,SLOT(receiveshopOwner(QString)));
    emit sendData("1023");
    emit sendshopOwner(this->ownerid);
    ShopInformationPro->show();
}

void ShopDistribution::on_pushButton_24_clicked()
{
    ShopInformationPro =new ShopInformation;
    connect(this,SIGNAL(sendData(QString)),ShopInformationPro,SLOT(receiveData(QString)));
    connect(ShopInformationPro,SIGNAL(sendData(QString)),this,SLOT(receiveData(QString)));
    connect(this,SIGNAL(sendshopOwner(QString)),ShopInformationPro,SLOT(receiveshopOwner(QString)));
    emit sendData("1024");
    emit sendshopOwner(this->ownerid);
    ShopInformationPro->show();
}

void ShopDistribution::on_pushButton_25_clicked()
{
    ShopInformationPro =new ShopInformation;
    connect(this,SIGNAL(sendData(QString)),ShopInformationPro,SLOT(receiveData(QString)));
    connect(ShopInformationPro,SIGNAL(sendData(QString)),this,SLOT(receiveData(QString)));
    connect(this,SIGNAL(sendshopOwner(QString)),ShopInformationPro,SLOT(receiveshopOwner(QString)));
    emit sendData("1025");
    emit sendshopOwner(this->ownerid);
    ShopInformationPro->show();
}

void ShopDistribution::on_pushButton_26_clicked()
{
    ShopInformationPro =new ShopInformation;
    connect(this,SIGNAL(sendData(QString)),ShopInformationPro,SLOT(receiveData(QString)));
    connect(ShopInformationPro,SIGNAL(sendData(QString)),this,SLOT(receiveData(QString)));
    connect(this,SIGNAL(sendshopOwner(QString)),ShopInformationPro,SLOT(receiveshopOwner(QString)));
    emit sendData("1026");
    emit sendshopOwner(this->ownerid);
    ShopInformationPro->show();
}

void ShopDistribution::on_pushButton_27_clicked()
{
    ShopInformationPro =new ShopInformation;
    connect(this,SIGNAL(sendData(QString)),ShopInformationPro,SLOT(receiveData(QString)));
    connect(ShopInformationPro,SIGNAL(sendData(QString)),this,SLOT(receiveData(QString)));
    connect(this,SIGNAL(sendshopOwner(QString)),ShopInformationPro,SLOT(receiveshopOwner(QString)));
    emit sendData("1027");
    emit sendshopOwner(this->ownerid);
    ShopInformationPro->show();
}

void ShopDistribution::on_pushButton_28_clicked()
{
    ShopInformationPro =new ShopInformation;
    connect(this,SIGNAL(sendData(QString)),ShopInformationPro,SLOT(receiveData(QString)));
    connect(ShopInformationPro,SIGNAL(sendData(QString)),this,SLOT(receiveData(QString)));
    connect(this,SIGNAL(sendshopOwner(QString)),ShopInformationPro,SLOT(receiveshopOwner(QString)));
    emit sendData("1028");
    emit sendshopOwner(this->ownerid);
    ShopInformationPro->show();
}

void ShopDistribution::on_pushButton_29_clicked()
{
    ShopInformationPro =new ShopInformation;
    connect(this,SIGNAL(sendData(QString)),ShopInformationPro,SLOT(receiveData(QString)));
    connect(ShopInformationPro,SIGNAL(sendData(QString)),this,SLOT(receiveData(QString)));
    connect(this,SIGNAL(sendshopOwner(QString)),ShopInformationPro,SLOT(receiveshopOwner(QString)));
    emit sendData("1029");
    emit sendshopOwner(this->ownerid);
    ShopInformationPro->show();
}

void ShopDistribution::on_pushButton_30_clicked()
{
    ShopInformationPro =new ShopInformation;
    connect(this,SIGNAL(sendData(QString)),ShopInformationPro,SLOT(receiveData(QString)));
    connect(ShopInformationPro,SIGNAL(sendData(QString)),this,SLOT(receiveData(QString)));
    connect(this,SIGNAL(sendshopOwner(QString)),ShopInformationPro,SLOT(receiveshopOwner(QString)));
    emit sendData("1030");
    emit sendshopOwner(this->ownerid);
    ShopInformationPro->show();
}

void ShopDistribution::on_pushButton_31_clicked()
{
    ShopInformationPro =new ShopInformation;
    connect(this,SIGNAL(sendData(QString)),ShopInformationPro,SLOT(receiveData(QString)));
    connect(ShopInformationPro,SIGNAL(sendData(QString)),this,SLOT(receiveData(QString)));
    connect(this,SIGNAL(sendshopOwner(QString)),ShopInformationPro,SLOT(receiveshopOwner(QString)));
    emit sendData("1031");
    emit sendshopOwner(this->ownerid);
    ShopInformationPro->show();
}

void ShopDistribution::on_pushButton_32_clicked()
{
    ShopInformationPro =new ShopInformation;
    connect(this,SIGNAL(sendData(QString)),ShopInformationPro,SLOT(receiveData(QString)));
    connect(ShopInformationPro,SIGNAL(sendData(QString)),this,SLOT(receiveData(QString)));
    connect(this,SIGNAL(sendshopOwner(QString)),ShopInformationPro,SLOT(receiveshopOwner(QString)));
    emit sendData("1032");
    emit sendshopOwner(this->ownerid);
    ShopInformationPro->show();
}

void ShopDistribution::on_pushButton_33_clicked()
{
    ShopInformationPro =new ShopInformation;
    connect(this,SIGNAL(sendData(QString)),ShopInformationPro,SLOT(receiveData(QString)));
    connect(ShopInformationPro,SIGNAL(sendData(QString)),this,SLOT(receiveData(QString)));
    connect(this,SIGNAL(sendshopOwner(QString)),ShopInformationPro,SLOT(receiveshopOwner(QString)));
    emit sendData("1033");
    emit sendshopOwner(this->ownerid);
    ShopInformationPro->show();
}

void ShopDistribution::on_pushButton_34_clicked()
{
    ShopInformationPro =new ShopInformation;
    connect(this,SIGNAL(sendData(QString)),ShopInformationPro,SLOT(receiveData(QString)));
    connect(ShopInformationPro,SIGNAL(sendData(QString)),this,SLOT(receiveData(QString)));
    connect(this,SIGNAL(sendshopOwner(QString)),ShopInformationPro,SLOT(receiveshopOwner(QString)));
    emit sendData("1034");
    emit sendshopOwner(this->ownerid);
    ShopInformationPro->show();
}

void ShopDistribution::on_pushButton_35_clicked()
{
    ShopInformationPro =new ShopInformation;
    connect(this,SIGNAL(sendData(QString)),ShopInformationPro,SLOT(receiveData(QString)));
    connect(ShopInformationPro,SIGNAL(sendData(QString)),this,SLOT(receiveData(QString)));
    connect(this,SIGNAL(sendshopOwner(QString)),ShopInformationPro,SLOT(receiveshopOwner(QString)));
    emit sendData("1035");
    emit sendshopOwner(this->ownerid);
    ShopInformationPro->show();
}

void ShopDistribution::on_pushButton_36_clicked()
{
    ShopInformationPro =new ShopInformation;
    connect(this,SIGNAL(sendData(QString)),ShopInformationPro,SLOT(receiveData(QString)));
    connect(ShopInformationPro,SIGNAL(sendData(QString)),this,SLOT(receiveData(QString)));
    connect(this,SIGNAL(sendshopOwner(QString)),ShopInformationPro,SLOT(receiveshopOwner(QString)));
    emit sendData("1036");
    emit sendshopOwner(this->ownerid);
    ShopInformationPro->show();
}
