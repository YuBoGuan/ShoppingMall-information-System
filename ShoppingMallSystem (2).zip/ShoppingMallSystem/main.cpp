﻿#include "mainwindow.h"
#include"shopdatabase.h"
#include <QApplication>
#include"database.h"
#include"login.h"
#include"shopdistribution.h"
#include"successfulpayment.h"
#include"shopowner.h"
#include"companystaff.h"
int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    MainWindow w;
    DataBase w1;
    login w2;
    ShopDistribution w3;
    SuccessfulPayment w4;
    shopOwner w5;
    companyStaff w6;
    w1.show();
    w2.show();
    //w3.show();
    //w.show();
    //w4.show();
    //w5.show();
    //w6.show();

    return a.exec();
}
