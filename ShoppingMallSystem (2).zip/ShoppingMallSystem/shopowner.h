﻿#ifndef SHOPOWNER_H
#define SHOPOWNER_H

#include <QMainWindow>
#include"shopdistribution.h"
#include"payment.h"
#include"sublease.h"
#include"personalcenter.h"

namespace Ui {
class shopOwner;
}

class shopOwner : public QMainWindow
{
    Q_OBJECT

public:
    explicit shopOwner(QWidget *parent = nullptr);
    ~shopOwner();

signals:
    void sendDataToShopDistribution(QString data);
    void sendDataToPersonalCenter(QString data);

private slots:
    void  receiveData(QString identity);

    void  receiveDataFromLogin(QString identity);

    void on_pushButton_APplyForAdmission_clicked();

    void on_pushButton_Sublease_clicked();

    void on_pushButton_Payment_clicked();

    void on_pushButton_PersonalCenter_clicked();

private:
    Ui::shopOwner *ui;

    //进场看看
    ShopDistribution *APplyForAdmissionPro;
    //缴纳费用
    Payment *PaymentPro;
    //申请转租
    Sublease *SubleasePro;
    //个人中心
    PersonalCenter *PersonalCenterPro;

    QString ownerid;
};

#endif // SHOPOWNER_H
