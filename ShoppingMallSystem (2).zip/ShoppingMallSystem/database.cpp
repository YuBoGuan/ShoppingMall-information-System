﻿#include "database.h"
#include "ui_database.h"
#include <QSqlDatabase>
#include <QDebug>
#include <QMessageBox>
#include <QSqlError>
#include <QSqlQuery>//对sql语句进行操作
#include <QVariantList>
#include <QSqlTableModel>
#include <QSqlRecord>
#include <QMenuBar>
#include <QMenu>

DataBase::DataBase(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::DataBase)
{
    ui->setupUi(this);

    this->databaseType="shop";
    ui->label_database->setText(this->databaseType);
    //打印qt支持的数据库驱动
    qDebug()<<QSqlDatabase::drivers();

    //添加数据库
    QSqlDatabase db=QSqlDatabase::addDatabase("QSQLITE");

    //连接数据库
    /*
      数据库中的表：
      商铺信息表 shop
      业主信息表 shopOwner
      公司员工表 companyStaff
    */
    db.setDatabaseName("info.db");


    //打开数据库
    if(!db.open())
    {
        QMessageBox::warning(this,QStringLiteral("打开错误"),db.lastError().text());
        return;
    }


    this->databaseType="shopOwner";
    //添加列
    QSqlQuery query01;
    QString sq2=QString("alter table %1 add mailBox varchar(255) NULL").arg(this->databaseType);
    //query01.exec(sq2);
/*
    query.exec("create table companyStaff("
               "id int primary key,"
               "passId int,"
               "StaffName varchar(255), "
               "StaffPost varchar(255), "
               "phonenumber int)");

    //批量插入
    //odbc风格
    //预处理语句
    //？相当于 占位符
    QString sq2=QString("insert into %1(id,passId,StaffName,StaffPost,phonenumber) values(?,?,?,?,?)").arg(this->databaseType);
    query.prepare(sq2);
    //给字段设置内容 list
    QVariantList idlist;
    idlist<<"1001"<<"1002"<<"1003";
    QVariantList passId;
    passId<<"123"<<"123"<<"123";
    QVariantList StaffName;
    StaffName<<QStringLiteral("张三")<<QStringLiteral("李四")<<QStringLiteral("王五");
    QVariantList StaffPost;
    StaffPost<<QStringLiteral("总经理")<<QStringLiteral("财务人员")<<QStringLiteral("物业人员");
    QVariantList phonenumber;
    phonenumber<<"110"<<"110"<<"110";

    //给字段绑定相应的值 按顺序绑定
    query.addBindValue(idlist);
    query.addBindValue(passId);
    query.addBindValue(StaffName);
    query.addBindValue(StaffPost);
    query.addBindValue(phonenumber);
    //执行预处理命令
    query.execBatch();
*/

    QSqlQuery query;
    QString sq1=QString("select * from '%1'").arg(this->databaseType);
    query.exec(sq1);

    while(query.next())
    {
        qDebug()<<query.value(0).toInt()
                <<query.value(1).toString()
                <<query.value(2).toInt()
                <<query.value(3).toInt()
                <<query.value(4).toInt();
    }

    setModel();

    //ui->tableView->setTextElideMode(QAbstractItemView::NoEditTriggers);
}

DataBase::~DataBase()
{
    delete ui;
}

 //设置模型
void DataBase::setModel()
{
    //设置模型
    model =new QSqlTableModel(this);
    model->setTable(this->databaseType);//指定表
    ui->label_database->setText(this->databaseType);

    //把model放在view里面
    ui->tableView->setModel(model);

    //显示model里的数据
    model->select();

    if(this->databaseType=="shop")
    {
        model->setHeaderData(0,Qt::Horizontal,QStringLiteral("商铺ID"));
        model->setHeaderData(1,Qt::Horizontal,QStringLiteral("商铺名称"));
        model->setHeaderData(2,Qt::Horizontal,QStringLiteral("业主姓名"));
        model->setHeaderData(3,Qt::Horizontal,QStringLiteral("商铺租金（万元/月）"));
        model->setHeaderData(4,Qt::Horizontal,QStringLiteral("水费（元/月）"));
        model->setHeaderData(5,Qt::Horizontal,QStringLiteral("电费（元/月）"));
        model->setHeaderData(6,Qt::Horizontal,QStringLiteral("物业费（元/月）"));
        model->setHeaderData(7,Qt::Horizontal,QStringLiteral("合同ID"));
        model->setHeaderData(8,Qt::Horizontal,QStringLiteral("状态"));
        model->setHeaderData(9,Qt::Horizontal,QStringLiteral("面积"));
        model->setHeaderData(10,Qt::Horizontal,QStringLiteral("分类"));
    }

    if(this->databaseType=="shopOwner")
    {
        model->setHeaderData(0,Qt::Horizontal,QStringLiteral("登录账号"));
        model->setHeaderData(1,Qt::Horizontal,QStringLiteral("业主姓名"));
        model->setHeaderData(2,Qt::Horizontal,QStringLiteral("登录密码"));
        model->setHeaderData(3,Qt::Horizontal,QStringLiteral("商铺Id"));
        model->setHeaderData(4,Qt::Horizontal,QStringLiteral("电话"));
        model->setHeaderData(5,Qt::Horizontal,QStringLiteral("合同Id"));
        model->setHeaderData(6,Qt::Horizontal,QStringLiteral("商铺状态"));
        model->setHeaderData(7,Qt::Horizontal,QStringLiteral("邮箱"));
    }

    if(this->databaseType=="companyStaff")
    {
        model->setHeaderData(0,Qt::Horizontal,QStringLiteral("登录账号"));
        model->setHeaderData(1,Qt::Horizontal,QStringLiteral("登录密码"));
        model->setHeaderData(2,Qt::Horizontal,QStringLiteral("员工姓名"));
        model->setHeaderData(3,Qt::Horizontal,QStringLiteral("员工职位"));
        model->setHeaderData(4,Qt::Horizontal,QStringLiteral("电话"));
    }

    //设置model的编辑模式，手动提交修改
    model->setEditStrategy(QSqlTableModel::OnManualSubmit);
}

//添加
void DataBase::on_buttonAdd_clicked()
{
    //添加空记录
    QSqlRecord record=model->record();//获取空记录
    //获取行号
    int row=model->rowCount();
    model->insertRecord(row,record);
}

//确认修改
void DataBase::on_buttonSure_clicked()
{
    model->submitAll();//提交动作
}

//撤销修改
void DataBase::on_buttonCancel_clicked()
{
    model->revertAll();//取消所有动作
    model->submitAll();//提交所有动作
}

//删除
void DataBase::on_buttonDel_clicked()
{
    //获取选中的模型
   QItemSelectionModel *smodel=ui->tableView->selectionModel();
   //取出模型中的索引
   QModelIndexList list=smodel->selectedRows();
   //删除所有选中的行
   for(int i=0;i<list.size();i++)
   {
       model->removeRow(list.at(i).row());
   }

}

//查找
void DataBase::on_buttonFind_clicked()
{
    QString name=ui->lineEdit->text(); 
    QString str;
    if(this->databaseType=="shop")
    {
        str=QString("name='%1'").arg(name);
    }
    if(this->databaseType=="shopOwner")
    {
        str=QString("ownername='%1'").arg(name);
    }
    if(this->databaseType=="companyStaff")
    {
         str=QString("StaffName='%1'").arg(name);
    }
    model->setFilter(str);
    model->select();
    if( model->select()==NULL)
    {

    }
}

//显示所有数据
void DataBase::on_buttonShow_clicked()
{
    model->setTable(this->databaseType);//指定表

    //把model放在view里面
    ui->tableView->setModel(model);

    //显示model里的数据
    model->select();

    if(this->databaseType=="shop")
    {
        model->setHeaderData(0,Qt::Horizontal,QStringLiteral("商铺ID"));
        model->setHeaderData(1,Qt::Horizontal,QStringLiteral("商铺名称"));
        model->setHeaderData(2,Qt::Horizontal,QStringLiteral("业主姓名"));
        model->setHeaderData(3,Qt::Horizontal,QStringLiteral("商铺租金（万元/月）"));
        model->setHeaderData(4,Qt::Horizontal,QStringLiteral("水费（元/月）"));
        model->setHeaderData(5,Qt::Horizontal,QStringLiteral("电费（元/月）"));
        model->setHeaderData(6,Qt::Horizontal,QStringLiteral("物业费（元/月）"));
        model->setHeaderData(7,Qt::Horizontal,QStringLiteral("合同ID"));
        model->setHeaderData(8,Qt::Horizontal,QStringLiteral("状态"));
        model->setHeaderData(9,Qt::Horizontal,QStringLiteral("面积"));
        model->setHeaderData(10,Qt::Horizontal,QStringLiteral("分类"));
    }

    if(this->databaseType=="shopOwner")
    {
        model->setHeaderData(0,Qt::Horizontal,QStringLiteral("登录账号"));
        model->setHeaderData(1,Qt::Horizontal,QStringLiteral("业主姓名"));
        model->setHeaderData(2,Qt::Horizontal,QStringLiteral("登录密码"));
        model->setHeaderData(3,Qt::Horizontal,QStringLiteral("商铺Id"));
        model->setHeaderData(4,Qt::Horizontal,QStringLiteral("电话"));
        model->setHeaderData(5,Qt::Horizontal,QStringLiteral("合同Id"));
        model->setHeaderData(6,Qt::Horizontal,QStringLiteral("商铺状态"));
        model->setHeaderData(7,Qt::Horizontal,QStringLiteral("邮箱"));
    }

    if(this->databaseType=="companyStaff")
    {
        model->setHeaderData(0,Qt::Horizontal,QStringLiteral("登录账号"));
        model->setHeaderData(1,Qt::Horizontal,QStringLiteral("登录密码"));
        model->setHeaderData(2,Qt::Horizontal,QStringLiteral("员工姓名"));
        model->setHeaderData(3,Qt::Horizontal,QStringLiteral("员工职位"));
        model->setHeaderData(4,Qt::Horizontal,QStringLiteral("电话"));
    }
}

//商铺信息
void DataBase::on_action_shop_triggered()
{
    this->databaseType="shop";
    ui->label->setText(QStringLiteral("请输入商铺名："));
    setModel();
}

//业主信息
void DataBase::on_action_shopowner_triggered()
{
    this->databaseType="shopOwner";
    ui->label->setText(QStringLiteral("请输入业主姓名："));
    setModel();
}

//公司职员信息
void DataBase::on_action_comoanystuff_triggered()
{
    this->databaseType="companyStaff";
    ui->label->setText(QStringLiteral("请输入员工姓名："));
    setModel();
}
