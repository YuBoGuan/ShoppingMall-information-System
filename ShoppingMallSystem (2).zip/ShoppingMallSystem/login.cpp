﻿#include "login.h"
#include "ui_login.h"
#include <QSqlDatabase>
#include <QDebug>
#include <QMessageBox>
#include <QSqlError>
#include <QSqlQuery>//对sql语句进行操作
#include <QVariantList>
#include <QSqlTableModel>
#include <QSqlRecord>

login::login(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::login)
{
    ui->setupUi(this);

    //固定窗口大小
    this->setFixedSize( this->width (),this->height ());

    //设置密码输入格式
    ui->lineEdit_passWord->setEchoMode(QLineEdit::PasswordEchoOnEdit );
    ui->lineEdit_passWord->setPlaceholderText(QStringLiteral("请输入密码"));

    ui->lineEdit_accountNumber->setPlaceholderText(QStringLiteral("登录账号"));

    this->login_register=QStringLiteral("登录/注册");

    //打印qt支持的数据库驱动
    qDebug()<<QSqlDatabase::drivers();

    //添加数据库
    QSqlDatabase db=QSqlDatabase::addDatabase("QSQLITE");

    //连接数据库
    /*
      数据库中的表：
      商铺信息表 shop
      业主信息表 shopOwner
      公司员工表 companyStaff
    */
    db.setDatabaseName("info.db");


    //打开数据库
    if(!db.open())
    {
        QMessageBox::warning(this,QStringLiteral("打开错误"),db.lastError().text());
        return;
    }


    this->StaffPost="";
}

login::~login()
{
    delete ui;
}

//登录选项
void login::on_pushButton_login_clicked()
{
    this->login_register=QStringLiteral("登录");
    ui->pushButton_login_register->setText(login_register);
}
//注册选项
void login::on_pushButton_register_clicked()
{
    this->login_register=QStringLiteral("注册");
     ui->pushButton_login_register->setText(login_register);
}
//登录或注册
void login::on_pushButton_login_register_clicked()
{
    if(login_register==QStringLiteral("登录"))
    {
        if(ui->radioButton_owner->isChecked())
        {
            this->StaffPost="";
            this->databaseType="shopOwner";
        }
        else if(ui->radioButton_manager->isChecked())
        {
            this->StaffPost=QStringLiteral("总经理");
            this->databaseType="companyStaff";
        }
        else if(ui->radioButton_marketing->isChecked())
        {
            this->StaffPost=QStringLiteral("市场管理人员");
            this->databaseType="companyStaff";
        }
        else if(ui->radioButton_financial->isChecked())
        {
            this->StaffPost=QStringLiteral("财务人员");
            this->databaseType="companyStaff";
        }
        else {
            QMessageBox::warning(this,"warning",QStringLiteral("请选择身份！ "),QMessageBox::Yes,QMessageBox::No);
            return;
        }

        //检查账号 密码 是否正确
        QSqlQuery query;
        QString sq0=QString("select * from '%1'").arg(this->databaseType);
        query.exec(sq0);

        bool flag=false;
        if(ui->radioButton_owner->isChecked())
        {
            while(query.next())
            {
                if(query.value(0).toInt()==ui->lineEdit_accountNumber->text().toInt()
                        &&query.value(2).toInt()==ui->lineEdit_passWord->text().toInt())
                {
                    flag=true;
                    break;
                }
            }
        }
        else {
            while(query.next())
            {
                if(query.value(0).toInt()==ui->lineEdit_accountNumber->text().toInt()
                        &&query.value(1).toInt()==ui->lineEdit_passWord->text().toInt())
                {
                    flag=true;
                    break;
                }
            }
        }

        if(flag)
        {
             //QMessageBox::warning(this,"warning",QStringLiteral("登录成功！ "),QMessageBox::Yes,QMessageBox::No);
            ownerPro = new shopOwner;
            staffPro = new companyStaff;
            //主窗口和子窗口之间传输数据
            //connect(pro,SIGNAL(sendData(QString)),this,SLOT(receiveData(QString)));
            connect(this,SIGNAL(sendDataToOwner(QString)),ownerPro,SLOT(receiveData(QString)));
            connect(this,SIGNAL(sendDataToStaff(QString)),staffPro,SLOT(receiveData(QString)));
            connect(this,SIGNAL(sendidToOwner(QString)),ownerPro,SLOT(receiveDataFromLogin(QString)));
            if(ui->radioButton_owner->isChecked())
            {
                emit sendDataToOwner(this->StaffPost);
                emit sendidToOwner(ui->lineEdit_accountNumber->text());
                ownerPro->show();
            }
            else
            {
                emit sendDataToStaff(this->StaffPost);
                staffPro->show();
            }
            //this->close();
        }
        else {
            QMessageBox::warning(this,"warning",QStringLiteral("账号或密码错误！ "),QMessageBox::Yes,QMessageBox::No);
            return;
        }
     return;
    }
    else if(login_register==QStringLiteral("注册"))
    {
        if(ui->radioButton_owner->isChecked())
        {
            this->StaffPost="";
            this->databaseType="shopOwner";
        }
        else if(ui->radioButton_manager->isChecked())
        {
            this->StaffPost=QStringLiteral("总经理");
            this->databaseType="companyStaff";
        }
        else if(ui->radioButton_marketing->isChecked())
        {
            this->StaffPost=QStringLiteral("市场管理人员");
            this->databaseType="companyStaff";
        }
        else if(ui->radioButton_financial->isChecked())
        {
            this->StaffPost=QStringLiteral("财务人员");
            this->databaseType="companyStaff";
        }
        else {
            QMessageBox::warning(this,"warning",QStringLiteral("请选择身份！ "),QMessageBox::Yes,QMessageBox::No);
            return;
        }

        //检查账号是否存在
        QSqlQuery query;
        QString sq0=QString("select * from '%1'").arg(this->databaseType);
        query.exec(sq0);

        bool flag=false;
        while(query.next())
        {
            if(query.value(0).toInt()==ui->lineEdit_accountNumber->text().toInt())
            {
                flag=true;
                break;
            }
        }
        if(flag)
        {
             QMessageBox::warning(this,"warning",QStringLiteral("该账号已存在！ "),QMessageBox::Yes,QMessageBox::No);
             return;
        }

        //注册 写入对应的表
        QSqlQuery query1;
        QString str1;
        if(ui->radioButton_owner->isChecked())
        {
            str1=QString("insert into '%1'(id,passId) values('%2','%3')")
                    .arg(this->databaseType)
                    .arg(ui->lineEdit_accountNumber->text().toInt())
                    .arg(ui->lineEdit_passWord->text());
        }
        else {
            str1=QString("insert into '%1'(id,passId,StaffPost) values('%2','%3','%4')")
                    .arg(this->databaseType)
                    .arg(ui->lineEdit_accountNumber->text().toInt())
                    .arg(ui->lineEdit_passWord->text())
                    .arg(this->StaffPost);
        }
        query1.exec(str1);

        QMessageBox::warning(this,"warning",QStringLiteral("注册账号成功！ "),QMessageBox::Yes,QMessageBox::No);
        //this->close();
    }
    else {
        QMessageBox::warning(this,"warning",QStringLiteral("请选择操作类型！ "),QMessageBox::Yes,QMessageBox::No);
    }
}
